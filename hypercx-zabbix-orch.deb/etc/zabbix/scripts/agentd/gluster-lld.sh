#!/bin/bash

#----------------------------------------------------------------------------------------------+
# Author: Franco Diaz Hurtado                                                                  |
# Owner: Virtalus                                                                              |
# Script version: 1.0.0                                                                        |
# Brief summary of the script: The script gather all possible gluster volumes and build the LLD|
#                              MACRO in json format.                                           |
#                              This script is for orchestrators only.                          |
#----------------------------------------------------------------------------------------------+

# Main vars
if [ ! -f /tmp/vollist.tmp ];
  then
    touch /tmp/vollist.tmp
fi
file=/tmp/vollist.tmp
if [ ! -f /tmp/lld.vol ];
  then
    touch /tmp/lld.vol
fi
jsfile=/tmp/lld.vol
df -hT | grep fuse.glusterfs | grep -v '/dev' | awk -F '/' '{print $2}' | awk '{print $1}' > $file
volcount=$(cat $file | wc -l)

# Body script
## Build the LLD MACRO  for Gluster Volname in json format
for (( i=1; $i <= $volcount; i++ ))
  do
    volname=$(sed -n ${i}p $file)
    if [ "$i" -eq 1 ];
      then
        cat << EOF > $jsfile
[
{"{#VOL}":"$volname"}
EOF
      elif [ "$i" -gt 1 ] && [ "$i" -lt $volcount ];
        then
          cat << EOF >> $jsfile
,{"{#VOL}":"$volname"}
EOF
      elif [ "$i" -eq $volcount ];
        then
          cat << EOF >> $jsfile
,{"{#VOL}":"$volname"}
EOF
    fi
done
echo "]" >> $jsfile

## Get LLD MACRO for Gluster volname in json format
cat $jsfile

exit 0
