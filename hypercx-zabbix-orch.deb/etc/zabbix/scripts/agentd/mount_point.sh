#!/bin/bash

#----------------------------------------------------------------------------------------------+
# Author: Franco Diaz Hurtado                                                                  |
# Owner: Virtalus                                                                              |
# Script version: 1.0.0                                                                        |
# Brief summary of the script: The script checks if all Gluster, NFS and VDO Mount Point are   |
#                              online.                                                         |
#                              - If "1": All Mount Points are online                           |
#                              - If "0": Atleast one Mount Point is offline                    |
#                              This script be used by nodes, orchestrators and Vault.          |
#----------------------------------------------------------------------------------------------+

# Main functions
mp_status(){
if [ $mp_count -eq $mp_on ];
  then
    echo 1
  else
    echo 0
fi
}

# Body script
cat /etc/fstab | grep gluster_mount | grep -vE "^#" >/dev/null 2>&1
if [ $? -eq 0 ];
  then
    ## Gluster Mount Point && NFS Mount Point
    mp_count=$(cat /etc/fstab | egrep "gluster_mount|nfs" | grep -vE "^#" | wc -l)
    mp_on=$(df -hT | egrep "fuse.glusterfs|nfs" | wc -l)
  else
    ## VDO Mount Point
    mp_count=$(cat /etc/fstab | grep vault_vdo | grep -vE "^#" | wc -l)
    mp_on=$(df -hT | grep vault_vdo | wc -l)
fi
mp_status

exit 0
