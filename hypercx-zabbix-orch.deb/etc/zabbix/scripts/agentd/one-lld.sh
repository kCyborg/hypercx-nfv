#!/bin/bash

#----------------------------------------------------------------------------------------------+
# Author: Franco Diaz Hurtado                                                                  |
# Owner: Virtalus                                                                              |
# Script version: 1.0.0                                                                        |
# Brief summary of the script: The script will gather all IDs for:                             |
#                              HOST-KVM, CLUSTER-KVM, DATASTORE, VNET, GROUP, USER, VM, IMAGE  |
#                              With these IDs will build the LLD MACRO in json format.         |
#                              This script is for orchestrators only.                          |
#----------------------------------------------------------------------------------------------+

# Main functions
## Check if json file exist
check_jsfile(){
  if [ -f $jsfile ];
    then
      ## Erase file content
      cat /dev/null > $jsfile
    else
      touch $jsfile
fi
}

print_info(){
  ## Get LLD MACRO for HOST_ID in json format
  cat $jsfile
  ## Exiting from script
  exit 0
}

build_lld_macro(){
## Build the LLD MACRO in json format
  if [ $count -eq 1 ];
    then
      cat << EOF >> $jsfile
[
{"{#$arg}":"$first_id"}
]
EOF
    else
      for i in "${id[@]}"
        do
          if [ "$i" == "$first_id" ];
            then
              cat << EOF >> $jsfile
[
{"{#$arg}":"$i"},
EOF
            elif [ "$i" == "$last_id" ];
              then
                cat << EOF >> $jsfile
{"{#$arg}":"$i"}
]
EOF
              else
                cat << EOF >> $jsfile
{"{#$arg}":"$i"},
EOF
          fi
      done
  fi
}

# Body script
case $1 in
  HOST-KVM)
    ## Vars
    command=$(onehost list | grep KVM | awk '{print $1}')
    count=$(echo "$command" | wc -l)
    list=$(echo "$command")
    first_id=$(echo "$command" | head -n 1)
    last_id=$(echo "$command" | tail -n 1)
    id=(`echo $list | tr ' ' ' '`)
    jsfile=/tmp/lld.HOSTKVMID
    arg=HOSTKVMID

    ## Body
    check_jsfile
    build_lld_macro
    print_info
    ;;

  CLUSTER-KVM)
    ## Vars
    command=$(onecluster list | grep KVM | awk '{print $1}')
    count=$(echo "$command" | wc -l)
    list=$(echo "$command")
    first_id=$(echo "$command" | head -n 1)
    last_id=$(echo "$command" | tail -n 1)
    id=(`echo $list | tr ' ' ' '`)
    jsfile=/tmp/lld.cluster-kvm_id
    arg=CLUSTERKVMID

    ## Body
    check_jsfile
    build_lld_macro
    print_info
    ;;

  DATASTORE)
    ## Vars
    command=$(onedatastore list | egrep "sys|img" | awk '{print $1}')
    count=$(echo "$command" | wc -l)
    list=$(echo "$command")
    first_id=$(echo "$command" | head -n 1)
    last_id=$(echo "$command" | tail -n 1)
    id=(`echo $list | tr ' ' ' '`)
    jsfile=/tmp/lld.datastore_id
    arg=DATASTOREID

    ## Body
    check_jsfile
    build_lld_macro
    print_info
    ;;

  VNET)
    ## Vars
    command=$(onevnet list | grep br | awk '{print $1}')
    count=$(echo "$command" | wc -l)
    list=$(echo "$command")
    first_id=$(echo "$command" | head -n 1)
    last_id=$(echo "$command" | tail -n 1)
    id=(`echo $list | tr ' ' ' '`)
    jsfile=/tmp/lld.vnet_id
    arg=VNETID

    ## Body
    check_jsfile
    build_lld_macro
    print_info
    ;;

  USER)
    ## Vars
    command=$(oneuser list | grep -v ID | awk '{print $1}')
    count=$(echo "$command" | wc -l)
    list=$(echo "$command")
    first_id=$(echo "$command" | head -n 1)
    last_id=$(echo "$command" | tail -n 1)
    id=(`echo $list | tr ' ' ' '`)
    jsfile=/tmp/lld.user_id
    arg=USERID

    ## Body
    check_jsfile
    build_lld_macro
    print_info
    ;;

  GROUP)
    ## Vars
    command=$(onegroup list | grep -v ID | awk '{print $1}')
    count=$(echo "$command" | wc -l)
    list=$(echo "$command")
    first_id=$(echo "$command" | head -n 1)
    last_id=$(echo "$command" | tail -n 1)
    id=(`echo $list | tr ' ' ' '`)
    jsfile=/tmp/lld.user_id
    arg=GROUPID

    ## Body
    check_jsfile
    build_lld_macro
    print_info
    ;;

  VM)
    ## Vars
    command=$(onevm list | egrep "pend|hold|clon|prol|boot|runn|migr|hotp|snap|save|epil|shut|stop|susp|poff|unde|fail|unkn|clea|done" | awk '{print $1}')
    count=$(echo "$command" | wc -l)
    list=$(echo "$command")
    first_id=$(echo "$command" | head -n 1)
    last_id=$(echo "$command" | tail -n 1)
    id=(`echo $list | tr ' ' ' '`)
    jsfile=/tmp/lld.vm_id
    arg=VMID

    ## Body
    check_jsfile
    build_lld_macro
    print_info
    ;;

  IMAGE)
    ## Vars
    command=$(oneimage list | egrep "init|rdy|used|disa|lock|err|clon|dele" | awk '{print $1}')
    count=$(echo "$command" | wc -l)
    list=$(echo "$command")
    first_id=$(echo "$command" | head -n 1)
    last_id=$(echo "$command" | tail -n 1)
    id=(`echo $list | tr ' ' ' '`)
    jsfile=/tmp/lld.image_id
    arg=IMAGEID

    ## Body
    check_jsfile
    build_lld_macro
    print_info
    ;;

  *)
    ## Exiting from script
    exit 0
    ;;
esac
