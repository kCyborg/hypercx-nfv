#!/bin/bash

#----------------------------------------------------------------------------------------------+
# Author: Franco Diaz Hurtado                                                                  |
# Owner: Virtalus                                                                              |
# Script version: 1.0.7                                                                        |
# Brief summary of the script: Bashone is a script made in bash to gather specific information |
#                              of OpenNebula HOST-KVM|CLUSTER-KVM. The script interact directly|
#                              with the ON CLI to gather almost all required info. Some others |
#                              are obtained applying arithmetic logic operations to the        | 
#                              gathered ON CLI info.                                           |
#                              This script is for orchestrators only.                          |
#----------------------------------------------------------------------------------------------+

# Main functions
help(){
  clear
  printf '\n\033[01;32mLegend with examples below:\033[0m\n\033[01;32m---------------------------\033[0m\n\n\033[01;34mHOST-KVM)\033[0m Script will consider only hosts KVM. Requires \033[01;33m"host_id"\033[0m.\n  \033[01;35mTOTAL_MEM_B)\033[0m Total Memory RAM of the host in Bytes.\n  \033[01;35mALLOCATED_MEM_B)\033[0m Total Memory RAM allocated to VMs in Bytes.\n  \033[01;35mREAL_FREE_MEM_B)\033[0m Current unused Memory RAM of the host and part of it can be already allocated in Bytes.\n  \033[01;35mREAL_USED_MEM_B)\033[0m Current used Memory RAM of the host in Bytes.\n  \033[01;35mUNALLOCATED_MEM_B)\033[0m Total Memory RAM available for allocation in Bytes.\n  \033[01;35mALLOCATED_MEM_PERCENT)\033[0m Percent of Total Memory RAM allocated to VMs.\n  \033[01;35mREAL_USED_MEM_PERCENT)\033[0m Percent of Current Used Memory RAM by the host and part of it can be already allocated.\n  \033[01;35mTOTAL_CPU)\033[0m Total CPU of the host.\n  \033[01;35mALLOCATED_CPU)\033[0m Total CPU allocated to VMs.\n  \033[01;35mREAL_FREE_CPU)\033[0m Current unused CPU of the host and part of it can be already allocated.\n  \033[01;35mREAL_USED_CPU)\033[0m Current used CPU by the host and part of it can be already allocated.\n  \033[01;35mUNALLOCATED_CPU)\033[0m Total CPU available for allocation.\n  \033[01;35mALLOCATED_CPU_PERCENT)\033[0m Percent Total CPU allocated to VMs.\n  \033[01;35mREAL_USED_CPU_PERCENT)\033[0m Percent of Current Used CPU by the host and part of it can be already allocated.\n  \033[01;35mTOTAL_VM)\033[0m Total number of VMs in the host.\n  \033[01;35mRUNN_VM)\033[0m Total number of VMs in \033[01;33m"running"\033[0m state in the \033[01;33mhost\033[0m.\n  \033[01;35mPOFF_VM)\033[0m Total number of VMs in \033[01;33m"poweroff"\033[0m state in the \033[01;33mhost\033[0m.\n  \033[01;35mFAIL_VM)\033[0m Total number of VMs in \033[01;33m"failed"\033[0m state in the \033[01;33mhost\033[0m.\n  \033[01;35mUNKN_VM)\033[0m Total number of VMs in \033[01;33m"unknown"\033[0m state in the \033[01;33mhost\033[0m.\n\n  Example usage:\n  bash /path/to/script HOST-KVM <host_id> TOTAL_MEM_B\n\n\033[01;34mCLUSTER-KVM)\033[0m Script will consider only clusters KVM.\n  \033[01;35mTOTAL_MEM_B)\033[0m Total Memory RAM of the cluster in Bytes.\n  \033[01;35mALLOCATED_MEM_B)\033[0m Total Memory RAM allocated to VMs in Bytes.\n  \033[01;35mREAL_FREE_MEM_B)\033[0m Current unused Memory RAM of the cluster and part of it can be already allocated in Bytes.\n  \033[01;35mREAL_USED_MEM_B)\033[0m Current used Memory RAM of the cluster in Bytes.\n  \033[01;35mUNALLOCATED_MEM_B)\033[0m Total Memory RAM available for allocation in Bytes.\n  \033[01;35mALLOCATED_MEM_PERCENT)\033[0m Percent of Total Memory RAM allocated to VMs.\n  \033[01;35mREAL_USED_MEM_PERCENT)\033[0m Percent of Current Used Memory RAM by the cluster and part of it can be already allocated.\n  \033[01;35mTOTAL_CPU)\033[0m Total CPU of the cluster.\n  \033[01;35mALLOCATED_CPU)\033[0m Total CPU allocated to VMs.\n  \033[01;35mREAL_FREE_CPU)\033[0m Current unused CPU of the cluster and part of it can be already allocated.\n  \033[01;35mREAL_USED_CPU)\033[0m Current used CPU by the cluster and part of it can be already allocated.\n  \033[01;35mUNALLOCATED_CPU)\033[0m Total CPU available for allocation.\n  \033[01;35mALLOCATED_CPU_PERCENT)\033[0m Percent Total CPU allocated to VMs.\n  \033[01;35mREAL_USED_CPU_PERCENT)\033[0m Percent of Current Used CPU by the cluster and part of it can be already allocated.\n  \033[01;35mTOTAL_VM)\033[0m Total number of VMs in the cluster.\n  \033[01;35mRUNN_VM)\033[0m Total number of VMs in \033[01;33m"running"\033[0m state in the \033[01;33mcluster\033[0m.\n  \033[01;35mPOFF_VM)\033[0m Total number of VMs in \033[01;33m"poweroff"\033[0m state in the \033[01;33mcluster\033[0m.\n  \033[01;35mFAIL_VM)\033[0m Total number of VMs in \033[01;33m"failed"\033[0m state in the \033[01;33mcluster\033[0m.\n  \033[01;35mUNKN_VM)\033[0m Total number of VMs in \033[01;33m"unknown"\033[0m state in the \033[01;33mcluster\033[0m.\n\n  Example usage:\n  bash /path/to/script CLUSTER-KVM ALLOCATED_MEM_B\n\n\033[01;34mDATASTORE)\033[0m Script will consider all datastores of the cluster. Requires \033[01;33m"datastore_id"\033[0m.\n  \033[01;35mTOTAL_SIZE_B)\033[0m Total space of the datastore in Bytes.\n  \033[01;35mREAL_FREE_SIZE_B)\033[0m Current unused space of the datastore and part of it can be already allocated in Bytes.\n  \033[01;35mREAL_USED_SIZE_B)\033[0m Current used space of the datastore and part of it can be already allocated in Bytes.\n  \033[01;35mALLOCATED_SIZE_B)\033[0m Total space allocated to VMs or images in Bytes.\n  \033[01;35mUNALLOCATED_SIZE_B)\033[0m Total space available for allocation in Bytes.\n  \033[01;35mALLOCATED_SIZE_PERCENT)\033[0m Percent of total space allocated to VMs or images.\n\n  Example usage:\n  bash /path/to/script DATASTORE <datastore_id> TOTAL_SIZE_B\n\n\033[01;34mIMAGE)\033[0m Images available in the cluster.\n  \033[01;35mRDY_IMAGE)\033[0m Total number of images in \033[01;33m"ready"\033[0m state in the cluster.\n  \033[01;35mUSED_IMAGE)\033[0m Total number of images in \033[01;33m"used"\033[0m state in the cluster.\n  \033[01;35mERR_IMAGE)\033[0m Total number of images in \033[01;33m"error"\033[0m state in the cluster.\n  \033[01;35mLOCK_IMAGE)\033[0m Total number of images in \033[01;33m"lock"\033[0m state in the cluster.\n\n  Example usage:\n  bash /path/to/script IMAGE RDY_IMAGE\n\n\033[01;34mVNET)\033[0m Specific information related with the Virtual Network. Requires \033[01;33m"vnet_id"\033[0m.\n  \033[01;35mPOOL_SIZE)\033[0m Pool IP of the Virtual Network.\n  \033[01;35mALLOCATED_IP)\033[0m Ammount of allocated of the pool IP (leases).\n  \033[01;35mUNALLOCATED_IP)\033[0m Available ammount of the pool IP ready for allocation.\n\n  Example usage:\n  bash /path/to/script VNET <vnet_id> POOL_SIZE\n\n\033[01;34mGROUP)\033[0m Specific information of groups. Requires \033[01;33m"group_id"\033[0m.\n  \033[01;35mVM_QUOTA_TOTAL_MEM_B)\033[0m Total Memory RAM assigned to a group.\n  \033[01;35mVM_QUOTA_ALLOCATED_MEM_B)\033[0m Total Memory RAM that was already allocated in the group in Bytes.\n  \033[01;35mVM_QUOTA_UNALLOCATED_MEM_B)\033[0m Total Memory RAM available for allocation in the group in Bytes.\n  \033[01;35mVM_QUOTA_ALLOCATED_MEM_PERCENT)\033[0m Percent of the allocated Memory in the group.\n  \033[01;35mVM_QUOTA_TOTAL_CPU)\033[0m Total CPU assigned to a group.\n  \033[01;35mVM_QUOTA_ALLOCATED_CPU)\033[0m Total CPU that was already allocated in the group.\n  \033[01;35mVM_QUOTA_UNALLOCATED_CPU)\033[0m Total CPU available for allocation in the group.\033[0m\n  \033[01;35mVM_QUOTA_ALLOCATED_CPU_PERCENT)\033[0m Percent of the allocated CPU in the group.\n  \033[01;35mVM_QUOTA_SYSTEM_DISK_SIZE_B)\033[0m Total space of the group in Bytes.\n  \033[01;35mVM_QUOTA_SYSTEM_DISK_ALLOCATED_B)\033[0m Total space allocated by group users in Bytes.\n  \033[01;35mVM_QUOTA_SYSTEM_DISK_UNALLOCATED_B)\033[0m Available space not allocated in the group in Bytes.\n\n  Example usage:\n  bash /path/to/script GROUP <group_id> VM_QUOTA_TOTAL_MEM_B\n\n\033[01;34mUSER)\033[0m Specific information of users. Requires \033[01;33m"user_id"\033[0m.\n  \033[01;35mVM_QUOTA_ALLOCATED_MEM_B)\033[0m Total Memory RAM that was already allocated to a user from a group in Bytes.\n  \033[01;35mVM_QUOTA_UNALLOCATED_MEM_B)\033[0m Total Memory RAM available for allocation in the group that user belongs to in Bytes.\n  \033[01;35mVM_QUOTA_ALLOCATED_CPU)\033[0m Total CPU that was already allocated to a user from a group.\n  \033[01;35mVM_QUOTA_UNALLOCATED_CPU)\033[0m Total CPU available for allocation in the group that user belongs to.\n  \033[01;35mVM_QUOTA_SYSTEM_DISK_ALLOCATED_B)\033[0m Total space allocated by to a user from a group in Bytes.\n  \033[01;35mVM_QUOTA_SYSTEM_DISK_UNALLOCATED_B)\033[0m Available space not allocated in the group that user belongs to in Bytes.\n\n\n  Example usage:\n  bash /path/to/script USER <user_id> VM_QUOTA_ALLOCATED_MEM_B\n\n' | more
}

help_host(){
  clear
  printf '\n\033[01;34mHOST-KVM)\033[0m Script will consider only hosts KVM. Requires \033[01;33m"host_id"\033[0m.\n  \033[01;35mTOTAL_MEM_B)\033[0m Total Memory RAM of the host in Bytes.\n  \033[01;35mALLOCATED_MEM_B)\033[0m Total Memory RAM allocated to VMs in Bytes.\n  \033[01;35mREAL_FREE_MEM_B)\033[0m Current unused Memory RAM of the host and part of it can be already allocated in Bytes.\n  \033[01;35mREAL_USED_MEM_B)\033[0m Current used Memory RAM of the host in Bytes.\n  \033[01;35mUNALLOCATED_MEM_B)\033[0m Total Memory RAM available for allocation in Bytes.\n  \033[01;35mALLOCATED_MEM_PERCENT)\033[0m Percent of Total Memory RAM allocated to VMs.\n  \033[01;35mREAL_USED_MEM_PERCENT)\033[0m Percent of Current Used Memory RAM by the host and part of it can be already allocated.\n  \033[01;35mTOTAL_CPU)\033[0m Total CPU of the host.\n  \033[01;35mALLOCATED_CPU)\033[0m Total CPU allocated to VMs.\n  \033[01;35mREAL_FREE_CPU)\033[0m Current unused CPU of the host and part of it can be already allocated.\n  \033[01;35mREAL_USED_CPU)\033[0m Current used CPU by the host and part of it can be already allocated.\n  \033[01;35mUNALLOCATED_CPU)\033[0m Total CPU available for allocation.\n  \033[01;35mALLOCATED_CPU_PERCENT)\033[0m Percent Total CPU allocated to VMs.\n  \033[01;35mREAL_USED_CPU_PERCENT)\033[0m Percent of Current Used CPU by the host and part of it can be already allocated.\n  \033[01;35mTOTAL_VM)\033[0m Total number of VMs in the host.\n  \033[01;35mRUNN_VM)\033[0m Total number of VMs in \033[01;33m"running"\033[0m state in the \033[01;33mhost\033[0m.\n  \033[01;35mPOFF_VM)\033[0m Total number of VMs in \033[01;33m"poweroff"\033[0m state in the \033[01;33mhost\033[0m.\n  \033[01;35mFAIL_VM)\033[0m Total number of VMs in \033[01;33m"failed"\033[0m state in the \033[01;33mhost\033[0m.\n  \033[01;35mUNKN_VM)\033[0m Total number of VMs in \033[01;33m"unknown"\033[0m state in the \033[01;33mhost\033[0m.\n\n  Example usage:\n  bash /path/to/script HOST-KVM <host_id> TOTAL_MEM_B\n\n'
}

help_cluster(){
  clear
  printf '\n\033[01;34mCLUSTER-KVM)\033[0m Script will consider only hosts KVM or clusters KVM.\n  \033[01;35mTOTAL_MEM_B)\033[0m Total Memory RAM of the cluster in Bytes.\n  \033[01;35mALLOCATED_MEM_B)\033[0m Total Memory RAM allocated to VMs in Bytes.\n  \033[01;35mREAL_FREE_MEM_B)\033[0m Current unused Memory RAM of the cluster and part of it can be already allocated in Bytes.\n  \033[01;35mREAL_USED_MEM_B)\033[0m Current used Memory RAM of the cluster in Bytes.\n  \033[01;35mUNALLOCATED_MEM_B)\033[0m Total Memory RAM available for allocation in Bytes.\n  \033[01;35mALLOCATED_MEM_PERCENT)\033[0m Percent of Total Memory RAM allocated to VMs.\n  \033[01;35mREAL_USED_MEM_PERCENT)\033[0m Percent of Current Used Memory RAM by the cluster and part of it can be already allocated.\n  \033[01;35mTOTAL_CPU)\033[0m Total CPU of the cluster.\n  \033[01;35mALLOCATED_CPU)\033[0m Total CPU allocated to VMs.\n  \033[01;35mREAL_FREE_CPU)\033[0m Current unused CPU of the cluster and part of it can be already allocated.\n  \033[01;35mREAL_USED_CPU)\033[0m Current used CPU by the cluster and part of it can be already allocated.\n  \033[01;35mUNALLOCATED_CPU)\033[0m Total CPU available for allocation.\n  \033[01;35mALLOCATED_CPU_PERCENT)\033[0m Percent Total CPU allocated to VMs.\n  \033[01;35mREAL_USED_CPU_PERCENT)\033[0m Percent of Current Used CPU by the cluster and part of it can be already allocated.\n  \033[01;35mTOTAL_VM)\033[0m Total number of VMs in the cluster.\n  \033[01;35mRUNN_VM)\033[0m Total number of VMs in \033[01;33m"running"\033[0m state in the \033[01;33mcluster\033[0m.\n  \033[01;35mPOFF_VM)\033[0m Total number of VMs in \033[01;33m"poweroff"\033[0m state in the \033[01;33mcluster\033[0m.\n  \033[01;35mFAIL_VM)\033[0m Total number of VMs in \033[01;33m"failed"\033[0m state in the \033[01;33mcluster\033[0m.\n  \033[01;35mUNKN_VM)\033[0m Total number of VMs in \033[01;33m"unknown"\033[0m state in the \033[01;33mcluster\033[0m.\n\n  Example usage:\n  bash /path/to/script CLUSTER-KVM ALLOCATED_MEM_B\n\n'
}

help_datastore(){
  clear
  printf '\n\033[01;34mDATASTORE)\033[0m Script will consider all datastores of the cluster. Requires \033[01;33m"datastore_id"\033[0m.\n  \033[01;35mTOTAL_SIZE_B)\033[0m Total space of the datastore in Bytes.\n  \033[01;35mREAL_FREE_SIZE_B)\033[0m Current unused space of the datastore and part of it can be already allocated in Bytes.\n  \033[01;35mREAL_USED_SIZE_B)\033[0m Current used space of the datastore and part of it can be already allocated in Bytes.\n  \033[01;35mALLOCATED_SIZE_B)\033[0m Total space allocated to VMs or images in Bytes.\n  \033[01;35mUNALLOCATED_SIZE_B)\033[0m Total space available for allocation in Bytes.\n  \033[01;35mALLOCATED_SIZE_PERCENT)\033[0m Percent of total space allocated to VMs or images.\n\n  Example usage:\n  bash /path/to/script DATASTORE <datastore_id> TOTAL_SIZE_B\n\n'
}

help_image(){
  clear
  printf '\n\033[01;34mIMAGE)\033[0m Images available in the cluster.\n  \033[01;35mRDY_IMAGE)\033[0m Total number of images in \033[01;33m"ready"\033[0m state in the cluster.\n  \033[01;35mUSED_IMAGE)\033[0m Total number of images in \033[01;33m"used"\033[0m state in the cluster.\n  \033[01;35mERR_IMAGE)\033[0m Total number of images in \033[01;33m"error"\033[0m state in the cluster.\n  \033[01;35mLOCK_IMAGE)\033[0m Total number of images in \033[01;33m"lock"\033[0m state in the cluster.\n\n  Example usage:\n  bash /path/to/script IMAGE RDY_IMAGE\n\n'
}

help_vnet(){
  clear
  printf '\n\033[01;34mVNET)\033[0m Specific information related with the Virtual Network. Requires \033[01;33m"vnet_id"\033[0m.\n  \033[01;35mPOOL_SIZE)\033[0m Pool IP of the Virtual Network.\n  \033[01;35mALLOCATED_IP)\033[0m Ammount of allocated of the pool IP (leases).\n  \033[01;35mUNALLOCATED_IP)\033[0m Available ammount of the pool IP ready for allocation.\n\n  Example usage:\n  bash /path/to/script VNET <vnet_id> POOL_SIZE\n\n'
}

help_group(){
  clear
  printf '\n\033[01;34mGROUP)\033[0m Specific information of groups. Requires \033[01;33m"group_id"\033[0m.\n  \033[01;35mVM_QUOTA_TOTAL_MEM_B)\033[0m Total Memory RAM assigned to a group.\n  \033[01;35mVM_QUOTA_ALLOCATED_MEM_B)\033[0m Total Memory RAM that was already allocated in the group in Bytes.\n  \033[01;35mVM_QUOTA_UNALLOCATED_MEM_B)\033[0m Total Memory RAM available for allocation in the group in Bytes.\n  \033[01;35mVM_QUOTA_ALLOCATED_MEM_PERCENT)\033[0m Percent of the allocated Memory in the group.\n  \033[01;35mVM_QUOTA_TOTAL_CPU)\033[0m Total CPU assigned to a group.\n  \033[01;35mVM_QUOTA_ALLOCATED_CPU)\033[0m Total CPU that was already allocated in the group.\n  \033[01;35mVM_QUOTA_UNALLOCATED_CPU)\033[0m Total CPU available for allocation in the group.\033[0m\n  \033[01;35mVM_QUOTA_ALLOCATED_CPU_PERCENT)\033[0m Percent of the allocated CPU in the group.\n  \033[01;35mVM_QUOTA_SYSTEM_DISK_SIZE_B)\033[0m Total space of the group in Bytes.\n  \033[01;35mVM_QUOTA_SYSTEM_DISK_ALLOCATED_B)\033[0m Total space allocated by group users in Bytes.\n  \033[01;35mVM_QUOTA_SYSTEM_DISK_UNALLOCATED_B)\033[0m Available space not allocated in the group in Bytes.\n\n  Example usage:\n  bash /path/to/script GROUP <group_id> VM_QUOTA_TOTAL_MEM_B\n'
}

help_user(){
  clear
  printf '\n\033[01;34mUSER)\033[0m Specific information of users. Requires \033[01;33m"user_id"\033[0m.\n  \033[01;35mVM_QUOTA_ALLOCATED_MEM_B)\033[0m Total Memory RAM that was already allocated to a user from a group in Bytes.\n  \033[01;35mVM_QUOTA_UNALLOCATED_MEM_B)\033[0m Total Memory RAM available for allocation in the group that user belongs to in Bytes.\n  \033[01;35mVM_QUOTA_ALLOCATED_CPU)\033[0m Total CPU that was already allocated to a user from a group.\n  \033[01;35mVM_QUOTA_UNALLOCATED_CPU)\033[0m Total CPU available for allocation in the group that user belongs to.\n  \033[01;35mVM_QUOTA_SYSTEM_DISK_ALLOCATED_B)\033[0m Total space allocated by to a user from a group in Bytes.\n  \033[01;35mVM_QUOTA_SYSTEM_DISK_UNALLOCATED_B)\033[0m Available space not allocated in the group that user belongs to in Bytes.\n\n  Example usage:\n  bash /path/to/script USER <user_id> VM_QUOTA_ALLOCATED_MEM_B\n\n'
}

get_orch_status(){
leader=$(onezone show 0 | grep leader | awk '{print $2}')
host_name=$(cat /etc/hostname)
  ## Is this orchestrator the leader?
  if [ "${host_name}" != "${leader}" ]
    then
      ## This orchestrator is no the leader, then the requested info will be zero
      echo "0"
      ## Exiting from script
      exit 0
  fi
}

get_host_total_mem(){
  TOTAL_MEM_KB=$(onehost show $host_id -x | grep TOTAL_MEM | grep -oE '*[0-9]+')
  TOTAL_MEM_B=$((${TOTAL_MEM_KB}*1024))
}

get_host_allocated_mem(){
  ALLOCATED_MEM_KB=$(onehost show $host_id -x | grep MEM_USAGE | grep -oE '*[0-9]+')
  ALLOCATED_MEM_B=$((${ALLOCATED_MEM_KB}*1024))
}

get_host_real_free_mem(){
  REAL_FREE_MEM_KB=$(onehost show $host_id -x | grep FREE_MEM | grep -oE '*[0-9]+')
  REAL_FREE_MEM_B=$((${REAL_FREE_MEM_KB}*1024))
}

get_host_real_used_mem(){
  REAL_USED_MEM_KB=$(onehost show $host_id -x | grep USED_MEM | grep -oE '*[0-9]+')
  REAL_USED_MEM_B=$((${REAL_USED_MEM_KB}*1024))
}

get_host_unallocated_mem(){
  TOTAL_MEM_KB=$(onehost show $host_id -x | grep TOTAL_MEM | grep -oE '*[0-9]+')
  ALLOCATED_MEM_KB=$(onehost show $host_id -x | grep MEM_USAGE | grep -oE '*[0-9]+')
  UNALLOCATED_MEM_KB=$((${TOTAL_MEM_KB}-${ALLOCATED_MEM_KB}))
  UNALLOCATED_MEM_B=$((${UNALLOCATED_MEM_KB}*1024))
}

float_to_int(){
  echo "($float+0.5)/1" | bc
}

get_host_allocated_mem_percent(){
  # percent=(P/T)*100
  TOTAL_MEM_KB=$(onehost show $host_id -x | grep TOTAL_MEM | grep -oE '*[0-9]+')
  TOTAL_MEM_B=$((${TOTAL_MEM_KB}*1024))
  ALLOCATED_MEM_KB=$(onehost show $host_id -x | grep MEM_USAGE | grep -oE '*[0-9]+')
  ALLOCATED_MEM_B=$((${ALLOCATED_MEM_KB}*1024))
  T=$TOTAL_MEM_B
  P=$ALLOCATED_MEM_B
  D=$(echo "scale=2 ; $P / $T" | bc)
  float=$(expr $D*100 | bc)
  ALLOCATED_MEM_PERCENT=$(echo "$(float_to_int)")
}

get_host_real_used_mem_percent(){
  # percent=(P/T)*100
  TOTAL_MEM_KB=$(onehost show $host_id -x | grep TOTAL_MEM | grep -oE '*[0-9]+')
  TOTAL_MEM_B=$((${TOTAL_MEM_KB}*1024))
  REAL_USED_MEM_KB=$(onehost show $host_id -x | grep USED_MEM | grep -oE '*[0-9]+')
  REAL_USED_MEM_B=$((${REAL_USED_MEM_KB}*1024))
  T=$TOTAL_MEM_B
  P=$REAL_USED_MEM_B
  D=$(echo "scale=2 ; $P / $T" | bc)
  float=$(expr $D*100 | bc)
  REAL_USED_MEM_PERCENT=$(echo "$(float_to_int)")
}

get_host_total_cpu(){
  TOTAL_CPU=$(onehost show $host_id -x | grep TOTAL_CPU | grep -oE '*[0-9]+')
}

get_host_allocated_cpu(){
  ALLOCATED_CPU=$(onehost show $host_id -x | grep CPU_USAGE | grep -oE '*[0-9]+')
}

get_host_real_free_cpu(){
  REAL_FREE_CPU=$(onehost show $host_id -x | grep FREE_CPU | grep -oE '*[0-9]+')
}

get_host_real_used_cpu(){
  REAL_USED_CPU=$(onehost show $host_id -x | grep USED_CPU | grep -oE '*[0-9]+')
}

get_host_unallocated_cpu(){
  TOTAL_CPU=$(onehost show $host_id -x | grep TOTAL_CPU | grep -oE '*[0-9]+')
  ALLOCATED_CPU=$(onehost show $host_id -x | grep CPU_USAGE | grep -oE '*[0-9]+')
  UNALLOCATED_CPU=$((${TOTAL_CPU}-${ALLOCATED_CPU}))
}

get_host_allocated_cpu_percent(){
  # percent=(P/T)*100
  TOTAL_CPU=$(onehost show $host_id -x | grep TOTAL_CPU | grep -oE '*[0-9]+')
  ALLOCATED_CPU=$(onehost show $host_id -x | grep CPU_USAGE | grep -oE '*[0-9]+')
  T=$TOTAL_CPU
  P=$ALLOCATED_CPU
  D=$(echo "scale=2 ; $P / $T" | bc)
  float=$(expr $D*100 | bc)
  ALLOCATED_CPU_PERCENT=$(echo "$(float_to_int)")
}

get_host_real_used_cpu_percent(){
  # percent=(P/T)*100
  TOTAL_CPU=$(onehost show $host_id -x | grep TOTAL_CPU | grep -oE '*[0-9]+')
  REAL_USED_CPU=$(onehost show $host_id -x | grep USED_CPU | grep -oE '*[0-9]+')
  T=$TOTAL_CPU
  P=$REAL_USED_CPU
  D=$(echo "scale=2 ; $P / $T" | bc)
  float=$(expr $D*100 | bc)
  REAL_USED_CPU_PERCENT=$(echo "$(float_to_int)")
}

get_host_total_vm(){
  TOTAL_VM=$(onehost show $host_id | egrep "pend|hold|clon|prol|boot|runn|migr|hotp|snap|save|epil|shut|stop|susp|poff|unde|fail|unkn|clea|done" | wc -l)
}

get_host_runn_vm(){
  RUNN_VM=$(onehost show $host_id | grep runn | wc -l)
}

get_host_poff_vm(){
  POFF_VM=$(onehost show $host_id | grep poff | wc -l)
}

get_host_fail_vm(){
  FAIL_VM=$(onehost show $host_id | grep fail | wc -l)
}

get_host_unkn_vm(){
  UNKN_VM=$(onehost show $host_id | grep unkn | wc -l)
}

check_tmp_file(){
  if [ -d $tmpdir ];
    then
      if [ -f $tmpfile ];
        then
          cat /dev/null > $tmpfile
        else
          touch $tmpfile
      fi
    else
      mkdir -p $tmpdir
      touch $tmpfile
  fi
}

get_cluster-kvm_members_id(){
  command=$(onehost list | grep KVM | awk '{print $1}')
  count=$(echo "$command" | wc -l)
  list=$(echo "$command")
  id=(`echo $list | tr ' ' ' '`)
}

get_cluster_total_vm(){
  TOTAL_VM=$(onevm list | egrep "pend|hold|clon|prol|boot|runn|migr|hotp|snap|save|epil|shut|stop|susp|poff|unde|fail|unkn|clea|done" | wc -l)
}

get_cluster_runn_vm(){
  RUNN_VM=$(onevm list | grep runn | wc -l)
}

get_cluster_poff_vm(){
  POFF_VM=$(onevm list | grep poff | wc -l)
}

get_cluster_fail_vm(){
  FAIL_VM=$(onevm list | grep fail | wc -l)
}

get_cluster_unkn_vm(){
  UNKN_VM=$(onevm list | grep unkn | wc -l)
}

get_datastore_total_size(){
  TOTAL_SIZE_MB=$(onedatastore show $datastore_id -x | grep TOTAL_MB | grep -oE '*[0-9]+')
  TOTAL_SIZE_B=$((${TOTAL_SIZE_MB}*1024*1024))
}

get_datastore_real_free_size(){
  REAL_FREE_SIZE_MB=$(onedatastore show $datastore_id -x | grep FREE_MB | grep -oE '*[0-9]+')
  REAL_FREE_SIZE_B=$((${REAL_FREE_SIZE_MB}*1024*1024))
}

get_datastore_real_used_size(){
  REAL_USED_SIZE_MB=$(onedatastore show $datastore_id -x | grep USED_MB | grep -oE '*[0-9]+')
  REAL_USED_SIZE_B=$((${REAL_USED_SIZE_MB}*1024*1024))
}

get_allocated_vdisk_size(){
## Check if there are vdisks in order of MB
onevm show $i | egrep "images|system" | egrep -vw "images/logos|ERROR" | awk '{print $(NF-2)}' | awk -F "/" '{print $NF}' | grep M &> /dev/null
if [ $? -eq 0 ];
  then
    ## There are vdisks in order of MB
    B_from_MB=$(($(onevm show $i | egrep "images|system" | egrep -vw "images/logos|ERROR" | awk '{print $(NF-2)}' | awk -F "/" '{print $NF}' | grep M | rev | cut -c2- | rev | paste -sd+ - | bc)*1024*1024))
    ## Check if there are also vdisk in order of GB
    onevm show $i | egrep "images|system" | egrep -vw "images/logos|ERROR" | awk '{print $(NF-2)}' | awk -F "/" '{print $NF}' | grep G &> /dev/null
    if [ $? -eq 0 ];
      then
        ## There are vdisks in order of MB and GB
        B_from_GB=$(($(onevm show $i | egrep "images|system" | egrep -vw "images/logos|ERROR" | awk '{print $(NF-2)}' | awk -F "/" '{print $NF}' | grep G | rev | cut -c2- | rev | paste -sd+ - | bc)*1024*1024*1024))
        ## Check if there are also vdisk in order of TB
        onevm show $i | egrep "images|system" | egrep -vw "images/logos|ERROR" | awk '{print $(NF-2)}' | awk -F "/" '{print $NF}' | grep T &> /dev/null
        if [ $? -eq 0 ];
          then
            ## There are vdisks in order of MB, GB and TB
            B_from_TB=$(($(onevm show $i | egrep "images|system" | egrep -vw "images/logos|ERROR" | awk '{print $(NF-2)}' | awk -F "/" '{print $NF}' | grep T | rev | cut -c2- | rev | paste -sd+ - | bc)*1024*1024*1024*1024))
            VM_ALLOCATED_DISK_SIZE_B=$((${B_from_MB}+${B_from_GB}+${B_from_GB}))
          else
            ## There are only vdisks in order of MB and GB
            VM_ALLOCATED_DISK_SIZE_B=$((${B_from_MB}+${B_from_GB}))
        fi
      else
        ## There vdisks in order of MB, but not GB
        ## Check if there are also vdisks in order of TB
        onevm show $i | egrep "images|system" | egrep -vw "images/logos|ERROR" | awk '{print $(NF-2)}' | awk -F "/" '{print $NF}' | grep T &> /dev/null
        if [ $? -eq 0 ];
          then
            ## There are vdisks in order of MB and TB
            B_from_TB=$(($(onevm show $i | egrep "images|system" | egrep -vw "images/logos|ERROR" | awk '{print $(NF-2)}' | awk -F "/" '{print $NF}' | grep T | rev | cut -c2- | rev | paste -sd+ - | bc)*1024*1024*1024*1024))
            VM_ALLOCATED_DISK_SIZE_B=$((${B_from_MB}+${B_from_TB}))
          else
            ## There are only vdisks in order of MB
            VM_ALLOCATED_DISK_SIZE_B=$B_from_MB
        fi
    fi
  else
    ## Check if there are vdisk in order of GB
    onevm show $i | egrep "images|system" | egrep -vw "images/logos|ERROR" | awk '{print $(NF-2)}' | awk -F "/" '{print $NF}' | grep G &> /dev/null
    if [ $? -eq 0 ];
      then
        ## There are vdisks in order of GB
        B_from_GB=$(($(onevm show $i | egrep "images|system" | egrep -vw "images/logos|ERROR" | awk '{print $(NF-2)}' | awk -F "/" '{print $NF}' | grep G | rev | cut -c2- | rev | paste -sd+ - | bc)*1024*1024*1024))
        ## Check if there are also vdisks in order of TB
        onevm show $i | egrep "images|system" | egrep -vw "images/logos|ERROR" | awk '{print $(NF-2)}' | awk -F "/" '{print $NF}' | grep T &> /dev/null
        if [ $? -eq 0 ];
          then
            ## There vdisks in order of GB and TB, but not MB
            B_from_TB=$(($(onevm show $i | egrep "images|system" | egrep -vw "images/logos|ERROR" | awk '{print $(NF-2)}' | awk -F "/" '{print $NF}' | grep T | rev | cut -c2- | rev | paste -sd+ - | bc)*1024*1024*1024*1024))
            VM_ALLOCATED_DISK_SIZE_B=$((${B_from_GB}+${B_from_TB}))
          else
            ## There are only vdisks in order of GB
            VM_ALLOCATED_DISK_SIZE_B=$B_from_GB
        fi
      else
        ## Check if there are vdisks in order of TB
        onevm show $i | egrep "images|system" | egrep -vw "images/logos|ERROR" | awk '{print $(NF-2)}' | awk -F "/" '{print $NF}' | grep T &> /dev/null
        if [ $? -eq 0 ];
          then
            ## There are only vdisks in order of TB
            VM_ALLOCATED_DISK_SIZE_B=$(($(onevm show $i | egrep "images|system" | egrep -vw "images/logos|ERROR" | awk '{print $(NF-2)}' | awk -F "/" '{print $NF}' | grep T | rev | cut -c2- | rev | paste -sd+ - | bc)*1024*1024*1024*1024))
          else
            ## Is missing the M|G|T label for size
            ## Normally, VMs vdisks are in order of GB
            ## Until this inconsistence be fixed in the ON DB,
            ## the script will assume this vdisk is in the order of GB
            VM_ALLOCATED_DISK_SIZE_B=$(($(onevm show $i | egrep "images|system" | egrep -vw "images/logos|ERROR" | awk '{print $(NF-2)}' | awk -F "/" '{print $NF}' | paste -sd+ - | bc)*1024*1024*1024))
        fi
    fi
fi
}

get_allocated_img_size(){
## Check if there are CD images in order of MB
oneimage list | grep images | grep -w "CD" | awk '{print $(NF-4)}' | grep M &> /dev/null
if [ $? -eq 0 ];
  then
    ## There are CD images in order of MB
    B_from_MB=$(expr $(oneimage list | grep images | grep -w "CD" | awk '{print $(NF-4)}' | grep M | rev | cut -c2- | rev | paste -sd+ - | bc)*1024*1024 | bc)
    ## Check if there are also images in order of GB
    oneimage list | grep images | grep -w "CD" | awk '{print $(NF-4)}' | grep G &> /dev/null
    if [ $? -eq 0 ];
      then
        ## There are CD images in order of MB and GB
        B_from_GB=$(expr $(oneimage list | grep images | grep -w "CD" | awk '{print $(NF-4)}' | grep G | rev | cut -c2- | rev | paste -sd+ - | bc)*1024*1024*1024 | bc)
        ## Check if there are also vdisk in order of TB
        oneimage list | grep images | grep -w "CD" | awk '{print $(NF-4)}' | grep T &> /dev/null
        if [ $? -eq 0 ];
          then
            ## There are CD images in order of MB, GB and TB
            B_from_TB=$(expr $(oneimage list | grep images | grep -w "CD" | awk '{print $(NF-4)}' | grep T | rev | cut -c2- | rev | paste -sd+ - | bc)*1024*1024*1024*1024 | bc)
            TOTAL_IMG_ALLOCATED_SIZE_B=$(awk "BEGIN{ print ${B_from_MB} + ${B_from_GB} + ${B_from_TB} }")
          else
            ## There are only CD images in order of MB and GB
            TOTAL_IMG_ALLOCATED_SIZE_B=$(awk "BEGIN{ print ${B_from_MB} + ${B_from_GB} }")
        fi
      else
        ## There CD images in order of MB, but not GB
        ## Check if there are also CD images in order of TB
        oneimage list | grep images | grep -w "CD" | awk '{print $(NF-4)}' | grep T &> /dev/null
        if [ $? -eq 0 ];
          then
            ## There are CD images in order of MB and TB
            B_from_TB=$(expr $(oneimage list | grep images | grep -w "CD" | awk '{print $(NF-4)}' | grep T | rev | cut -c2- | rev | paste -sd+ - | bc)*1024*1024*1024*1024 | bc)
            TOTAL_IMG_ALLOCATED_SIZE_B=$(awk "BEGIN{ print ${B_from_MB} + ${B_from_TB} }")
          else
            ## There are only CD images in order of MB
            TOTAL_IMG_ALLOCATED_SIZE_B=$B_from_MB
        fi
    fi
  else
    ## Check if there are vdisk in order of GB
    oneimage list | grep images | grep -w "CD" | awk '{print $(NF-4)}' | grep G &> /dev/null
    if [ $? -eq 0 ];
      then
        ## There are CD images in order of GB
        B_from_MB=$(expr $(oneimage list | grep images | grep -w "CD" | awk '{print $(NF-4)}' | grep M | rev | cut -c2- | rev | paste -sd+ - | bc)*1024*1024 | bc)
        ## Check if there are also CD images in order of TB
        oneimage list | grep images | grep -w "CD" | awk '{print $(NF-4)}' | grep T &> /dev/null
        if [ $? -eq 0 ];
          then
            ## There images in order of GB and TB, but not MB
            B_from_MB=$(expr $(oneimage list | grep images | grep -w "CD" | awk '{print $(NF-4)}' | grep M | rev | cut -c2- | rev | paste -sd+ - | bc)*1024*1024 | bc)
            TOTAL_IMG_ALLOCATED_SIZE_B=$(awk "BEGIN{ print ${B_from_GB} + ${B_from_TB} }")
          else
            ## There are only images in order of GB
            TOTAL_IMG_ALLOCATED_SIZE_B=$B_from_GB
        fi
      else
        ## Check if there are CD images in order of TB
        oneimage list | grep images | grep -w "CD" | awk '{print $(NF-4)}' | grep T &> /dev/null
        if [ $? -eq 0 ];
          then
            ## There are only CD images in order of TB
            B_from_TB=$(expr $(oneimage list | grep images | grep -w "CD" | awk '{print $(NF-4)}' | grep T | rev | cut -c2- | rev | paste -sd+ - | bc)*1024*1024*1024*124 | bc)
          else
            ## There are no CD images
            TOTAL_IMG_ALLOCATED_SIZE_B=0
        fi
    fi
fi
}

get_image_total_img(){
  TOTAL_IMAGE=$(oneimage list | grep -w "images" | wc -l)
}

get_image_rdy_img(){
  RDY_IMAGE=$(oneimage list | grep -w "rdy" | wc -l)
}

get_image_used_img(){
  USED_IMAGE=$(oneimage list | grep -w "used" | wc -l)
}

get_image_err_img(){
  ERR_IMAGE=$(oneimage list | grep -w "err" | wc -l)
}

get_image_lock_img(){
  LOCK_IMAGE=$(oneimage list | grep -w "lock" | wc -l)
}

get_pool_size(){
  POOL_SIZE=$(onevnet show $vnet_id -x | grep SIZE | grep -oE '*[0-9]+')
}

get_allocated_ip(){
  ALLOCATED_IP=$(onevnet show $vnet_id | grep "USED LEASES" | grep -oE '*[0-9]+')
}

get_unallocated_ip(){
  POOL_SIZE=$(onevnet show $vnet_id -x | grep SIZE | grep -oE '*[0-9]+')
  ALLOCATED_IP=$(onevnet show $vnet_id | grep "USED LEASES" | grep -oE '*[0-9]+')
  UNALLOCATED_IP=$((${POOL_SIZE}-${ALLOCATED_IP}))
}

get_group_name(){
  GROUP_NAME=$(onegroup show $group_id -x | grep "<NAME>" | awk -F '</NAME>' '{print $1}' | cut -c9-)
}

get_group_vm_quota_total_mem(){
  VM_QUOTA_TOTAL_MEM_MB=$(onegroup show $group_id -x | grep -w "MEMORY" | grep -oE '*[0-9]+')
  if [ -z $VM_QUOTA_TOTAL_MEM_MB ];
    then
      ## Set value zero due to null var value
      VM_QUOTA_TOTAL_MEM_B=0
    elif [ $VM_QUOTA_TOTAL_MEM_MB -eq 1 ];
      then
        ## Set value zero due to null var value
        VM_QUOTA_TOTAL_MEM_B=0
    else
      VM_QUOTA_TOTAL_MEM_B=$((${VM_QUOTA_TOTAL_MEM_MB}*1024*1024))
  fi
}

get_group_vm_quota_allocated_mem(){
  VM_QUOTA_ALLOCATED_MEM_MB=$(onegroup show $group_id -x | grep -w "MEMORY_USED" | grep -oE '*[0-9]+')
  if [ $? -eq 1 ];
    then
      ## Set value zero due to null var value
      VM_QUOTA_ALLOCATED_MEM_B=0
    elif [ $VM_QUOTA_ALLOCATED_MEM_MB -eq 1 ];
      then
        ## Set value zero due to null var value
        VM_QUOTA_ALLOCATED_MEM_B=0
    else
      VM_QUOTA_ALLOCATED_MEM_B=$((${VM_QUOTA_ALLOCATED_MEM_MB}*1024*1024))
  fi
}

get_group_vm_quota_unallocated_mem(){
  VM_QUOTA_TOTAL_MEM_MB=$(onegroup show $group_id -x | grep -w "MEMORY" | grep -oE '*[0-9]+')
  if [ $? -eq 1 ];
    then
      ## Set value zero due to null var value
      VM_QUOTA_UNALLOCATED_MEM_B=0
    elif [ $VM_QUOTA_TOTAL_MEM_MB -eq 1 ];
      then
        ## Set value zero due to null var value
        VM_QUOTA_UNALLOCATED_MEM_B=0
    else
      VM_QUOTA_ALLOCATED_MEM_MB=$(onegroup show $group_id -x | grep -w "MEMORY_USED" | grep -oE '*[0-9]+')
      if [ $? -eq 1 ];
        then
          ## Set value zero due to null var value
          VM_QUOTA_UNALLOCATED_MEM_B=0
        elif [ $VM_QUOTA_ALLOCATED_MEM_MB -eq 1 ];
          then
            ## Set value zero due to null var value
            VM_QUOTA_UNALLOCATED_MEM_B=0
        else
            VM_QUOTA_UNALLOCATED_MEM_MB=$((${VM_QUOTA_TOTAL_MEM_MB}-${VM_QUOTA_ALLOCATED_MEM_MB}))
            VM_QUOTA_UNALLOCATED_MEM_B=$((${VM_QUOTA_UNALLOCATED_MEM_MB}*1024*1024))
      fi
  fi
}

get_group_vm_quota_allocated_mem_percent(){
  # percent=(P/T)*100

  VM_QUOTA_TOTAL_MEM_MB=$(onegroup show $group_id -x | grep -w "MEMORY" | grep -oE '*[0-9]+')
  if [ -z $VM_QUOTA_TOTAL_MEM_MB ];
    then
      ## Set value zero due to null var value
      VM_QUOTA_TOTAL_MEM_B=0
    elif [ $VM_QUOTA_TOTAL_MEM_MB -eq 1 ];
      then
        ## Set value zero due to null var value
        VM_QUOTA_TOTAL_MEM_B=0
    else
      VM_QUOTA_TOTAL_MEM_B=$((${VM_QUOTA_TOTAL_MEM_MB}*1024*1024))
  fi

  VM_QUOTA_ALLOCATED_MEM_MB=$(onegroup show $group_id -x | grep -w "MEMORY_USED" | grep -oE '*[0-9]+')
  if [ $? -eq 1 ];
    then
      ## Set value zero due to null var value
      VM_QUOTA_ALLOCATED_MEM_B=0
    elif [ $VM_QUOTA_ALLOCATED_MEM_MB -eq 1 ];
      then
        ## Set value zero due to null var value
        VM_QUOTA_ALLOCATED_MEM_B=0
    else
      VM_QUOTA_ALLOCATED_MEM_B=$((${VM_QUOTA_ALLOCATED_MEM_MB}*1024*1024))
  fi

  T=$VM_QUOTA_TOTAL_MEM_B
  P=$VM_QUOTA_ALLOCATED_MEM_B
  D=$(echo "scale=2 ; $P / $T" | bc)
  float=$(expr $D*100 | bc)
  VM_QUOTA_ALLOCATED_MEM_PERCENT=$(echo "$(float_to_int)")
}

get_group_vm_quota_total_cpu(){
  VM_QUOTA_TOTAL_CPU=$(onegroup list | grep -w "$GROUP_NAME" | awk '{print $NF}') 
  if [ -z $VM_QUOTA_TOTAL_CPU ];
    then
      ## Set value zero due to null var value
      VM_QUOTA_TOTAL_CPU=0.0
    elif [ "$VM_QUOTA_TOTAL_CPU" = "-" ];
      then
        ## Set value zero due to null var value
        VM_QUOTA_TOTAL_CPU=0.0
  fi
}

get_group_vm_quota_allocated_cpu(){
  VM_QUOTA_ALLOCATED_CPU=$(onegroup list | grep -w "$GROUP_NAME" | awk '{print $(NF-2)}')
  if [ -z $VM_QUOTA_ALLOCATED_CPU ];
    then
      ## Set value zero due to null var value
      VM_QUOTA_ALLOCATED_CPU=0.0
    elif [ $VM_QUOTA_ALLOCATED_CPU = "-" ];
      then
        ## Set value zero due to null var value
        VM_QUOTA_ALLOCATED_CPU=0.0
  fi
}

get_group_vm_quota_unallocated_cpu(){
  VM_QUOTA_TOTAL_CPU=$(onegroup list | grep -w "$GROUP_NAME" | awk '{print $NF}')
  if [ $? -eq 0 ];
    then
      if [ "$VM_QUOTA_TOTAL_CPU" != "-" ];
        then
          VM_QUOTA_ALLOCATED_CPU=$(onegroup list | grep -w "$GROUP_NAME" | awk '{print $(NF-2)}')
          if [ $? -eq 0 ];
            then
              VM_QUOTA_UNALLOCATED_CPU=$(awk "BEGIN{ print ${VM_QUOTA_TOTAL_CPU} - ${VM_QUOTA_ALLOCATED_CPU} }")
            else
              ## Set value zero due to null var value
              VM_QUOTA_UNALLOCATED_CPU=0.0
          fi
        else
          ## Set value zero due to null var value
          VM_QUOTA_UNALLOCATED_CPU=0.0
      fi
    else
      ## Set value zero due to null var value
      VM_QUOTA_UNALLOCATED_CPU=0.0
  fi
}

get_group_vm_quota_allocated_cpu_percent(){
  # percent=(P/T)*100

  VM_QUOTA_TOTAL_CPU=$(onegroup list | grep -w "$GROUP_NAME" | awk '{print $NF}') 
  if [ -z $VM_QUOTA_TOTAL_CPU ];
    then
      ## Set value zero due to null var value
      VM_QUOTA_TOTAL_CPU=0.0
    elif [ "$VM_QUOTA_TOTAL_CPU" = "-" ];
      then
        ## Set value zero due to null var value
        VM_QUOTA_TOTAL_CPU=0.0
  fi

  VM_QUOTA_ALLOCATED_CPU=$(onegroup list | grep -w "$GROUP_NAME" | awk '{print $(NF-2)}')
  if [ -z $VM_QUOTA_ALLOCATED_CPU ];
    then
      ## Set value zero due to null var value
      VM_QUOTA_ALLOCATED_CPU=0.0
    elif [ $VM_QUOTA_ALLOCATED_CPU = "-" ];
      then
        ## Set value zero due to null var value
        VM_QUOTA_ALLOCATED_CPU=0.0
  fi

  T=$VM_QUOTA_TOTAL_CPU
  P=$VM_QUOTA_ALLOCATED_CPU
  D=$(echo "scale=2 ; $P / $T" | bc)
  float=$(expr $D*100 | bc)
  VM_QUOTA_ALLOCATED_CPU_PERCENT=$(echo "$(float_to_int)")
}

get_group_vm_quota_system_disk_size(){
  VM_QUOTA_SYSTEM_DISK_SIZE_MB=$(onegroup show $group_id -x | grep -w "SYSTEM_DISK_SIZE" | grep -oE '*[0-9]+')
  if [ $? -eq 1 ];
    then
      ## Set value zero due to null var value
      VM_QUOTA_SYSTEM_DISK_SIZE_B=0
    elif [ $VM_QUOTA_SYSTEM_DISK_SIZE_MB -eq 1 ];
      then
        ## Set value zero due to null var value
        VM_QUOTA_SYSTEM_DISK_SIZE_B=0
    else
      VM_QUOTA_SYSTEM_DISK_SIZE_B=$((${VM_QUOTA_SYSTEM_DISK_SIZE_MB}*1024*1024))
  fi
}

get_group_vm_quota_system_disk_allocated(){
  VM_QUOTA_SYSTEM_DISK_ALLOCATED_MB=$(onegroup show $group_id -x | grep -w "SYSTEM_DISK_SIZE_USED" | grep -oE '*[0-9]+')
  if [ $? -eq 1 ];
    then
      ## Set value zero due to null var value
      VM_QUOTA_SYSTEM_DISK_ALLOCATED_B=0
    elif [ $VM_QUOTA_SYSTEM_DISK_ALLOCATED_MB -eq 1 ];
      then
        ## Set value zero due to null var value
        VM_QUOTA_SYSTEM_DISK_ALLOCATED_B=0
    else
      VM_QUOTA_SYSTEM_DISK_ALLOCATED_B=$((${VM_QUOTA_SYSTEM_DISK_ALLOCATED_MB}*1024*1024))
  fi
}

get_group_vm_quota_system_disk_unallocated(){
  VM_QUOTA_SYSTEM_DISK_SIZE_MB=$(onegroup show $group_id -x | grep -w "SYSTEM_DISK_SIZE" | grep -oE '*[0-9]+')
  if [ $? -eq 1 ];
    then
      ## Set value zero due to null var value
      VM_QUOTA_SYSTEM_DISK_UNALLOCATED_B=0
    elif [ $VM_QUOTA_SYSTEM_DISK_SIZE_MB -eq 1 ];
      then
        ## Set value zero due to null var value
        VM_QUOTA_SYSTEM_DISK_UNALLOCATED_B=0
    else
      VM_QUOTA_SYSTEM_DISK_ALLOCATED_MB=$(onegroup show $group_id -x | grep -w "SYSTEM_DISK_SIZE_USED" | grep -oE '*[0-9]+')
      if [ $? -eq 1 ];
        then
          ## Set value zero due to null var value
          VM_QUOTA_SYSTEM_DISK_UNALLOCATED_B=0
        elif [ $VM_QUOTA_SYSTEM_DISK_ALLOCATED_MB -eq 1 ];
          then
            ## Set value zero due to null var value
            VM_QUOTA_SYSTEM_DISK_UNALLOCATED_B=0
          else
            VM_QUOTA_SYSTEM_DISK_UNALLOCATED_MB=$((${VM_QUOTA_SYSTEM_DISK_SIZE_MB}-${VM_QUOTA_SYSTEM_DISK_ALLOCATED_MB}))
            VM_QUOTA_SYSTEM_DISK_UNALLOCATED_B=$((${VM_QUOTA_SYSTEM_DISK_UNALLOCATED_MB}*1024*1024))
      fi
  fi
}

get_user_name(){
  USER_NAME=$(oneuser show $user_id -x | grep "<NAME>" | awk -F '</NAME>' '{print $1}' | cut -c9-)
}

get_user_vm_quota_allocated_mem(){
  VM_QUOTA_ALLOCATED_MEM_MB=$(oneuser show $user_id -x | grep -w "MEMORY_USED" | grep -oE '*[0-9]+')
  if [ $? -eq 1 ];
    then
      ## Set value zero due to null var value
      VM_QUOTA_ALLOCATED_MEM_B=0
    elif [ $VM_QUOTA_ALLOCATED_MEM_MB -eq 1 ];
      then
        ## Set value zero due to null var value
        VM_QUOTA_ALLOCATED_MEM_B=0
    else
      VM_QUOTA_ALLOCATED_MEM_B=$((${VM_QUOTA_ALLOCATED_MEM_MB}*1024*1024))
  fi
}

get_user_vm_quota_unallocated_mem(){
  GID=$(oneuser show $user_id -x | grep -w "GID" | grep -oE '*[0-9]+')
  VM_QUOTA_TOTAL_MEM_MB=$(onegroup show $GID -x | grep -w "MEMORY" | grep -oE '*[0-9]+')
  if [ $? -eq 1 ];
    then
      ## Set value zero due to null var value
      VM_QUOTA_UNALLOCATED_MEM_B=0
    elif [ $VM_QUOTA_TOTAL_MEM_MB -eq 1 ];
      then
        ## Set value zero due to null var value
        VM_QUOTA_UNALLOCATED_MEM_B=0
    else
      VM_QUOTA_ALLOCATED_MEM_MB=$(onegroup show $GID -x | grep -w "MEMORY_USED" | grep -oE '*[0-9]+')
      if [ $? -eq 1 ];
        then
          VM_QUOTA_UNALLOCATED_MEM_B=$((${VM_QUOTA_TOTAL_MEM_MB}*1024*1024))
        else
          VM_QUOTA_UNALLOCATED_MEM_MB=$((${VM_QUOTA_TOTAL_MEM_MB}-${VM_QUOTA_ALLOCATED_MEM_MB}))
          VM_QUOTA_UNALLOCATED_MEM_B=$((${VM_QUOTA_UNALLOCATED_MEM_MB}*1024*1024))
      fi
  fi
}

get_user_vm_quota_allocated_cpu(){
  oneuser list > $tmpfile
  VM_QUOTA_ALLOCATED_CPU=$(cat $tmpfile | awk '{$4=""; print $0}' | grep -w "$USER_NAME" | awk '{print $(NF-2)}')
  if [ $? -eq 1 ];
    then
      ## Set value zero due to null var value
      VM_QUOTA_ALLOCATED_CPU=0.0
    elif [ "$VM_QUOTA_ALLOCATED_CPU" = "-" ];
      then
        ## Set value zero due to null var value
        VM_QUOTA_ALLOCATED_CPU=0.0
  fi
}

get_user_vm_quota_unallocated_cpu(){
  VM_QUOTA_TOTAL_CPU=$(onegroup list | grep -w "$GROUP_NAME" | awk '{print $NF}')
  if [ $? -eq 1 ];
    then
      ## Set value zero due to null var value
      VM_QUOTA_UNALLOCATED_CPU=0.0
    elif [ "$VM_QUOTA_TOTAL_CPU" = "-" ];
      then
        ## Set value zero due to null var value
        VM_QUOTA_UNALLOCATED_CPU=0.0
    else
      VM_QUOTA_ALLOCATED_CPU=$(onegroup list | grep -w "$GID" | awk '{print $(NF-2)}')
      if [ $? -eq 1 ];
        then
          ## Set value zero due to null var value
          VM_QUOTA_UNALLOCATED_CPU=$VM_QUOTA_TOTAL_CPU
        elif [ "$VM_QUOTA_ALLOCATED_CPU" = "-" ];
          then
            ## Set value zero due to null var value
            VM_QUOTA_UNALLOCATED_CPU=$VM_QUOTA_TOTAL_CPU
        else
          VM_QUOTA_UNALLOCATED_CPU=$(awk "BEGIN{ print ${VM_QUOTA_TOTAL_CPU} - ${VM_QUOTA_ALLOCATED_CPU} }")
      fi
  fi
}

get_user_vm_quota_system_disk_allocated(){
  VM_QUOTA_SYSTEM_DISK_ALLOCATED_MB=$(oneuser show $user_id -x | grep -w "SYSTEM_DISK_SIZE_USED" | grep -oE '*[0-9]+')
  if [ $? -eq 1 ];
    then
      ## Set value zero due to null var value
      VM_QUOTA_SYSTEM_DISK_ALLOCATED_B=0
    elif [ $VM_QUOTA_SYSTEM_DISK_ALLOCATED_MB -eq 1 ]
      then
        ## Set value zero due to null var value
        VM_QUOTA_SYSTEM_DISK_ALLOCATED_B=0
    else
      VM_QUOTA_SYSTEM_DISK_ALLOCATED_B=$((${VM_QUOTA_SYSTEM_DISK_ALLOCATED_MB}*1024*1024))
  fi
}

get_user_vm_quota_system_disk_unallocated(){
  GID=$(oneuser show $user_id -x | grep -w "GID" | grep -oE '*[0-9]+')
  VM_QUOTA_SYSTEM_DISK_SIZE_MB=$(onegroup show $GID -x | grep -w "SYSTEM_DISK_SIZE" | grep -oE '*[0-9]+')
  if [ $? -eq 1 ];
    then
      ## Set value zero due to null var value
      VM_QUOTA_SYSTEM_DISK_UNALLOCATED_B=0
    elif [ $VM_QUOTA_SYSTEM_DISK_SIZE_MB -eq 1 ];
      then
        ## Set value zero due to null var value
        VM_QUOTA_SYSTEM_DISK_UNALLOCATED_B=0
    else
      VM_QUOTA_SYSTEM_DISK_ALLOCATED_MB=$(onegroup show $GID -x | grep -w "SYSTEM_DISK_SIZE_USED" | grep -oE '*[0-9]+')
      if [ $? -eq 1 ];
        then
          VM_QUOTA_SYSTEM_DISK_UNALLOCATED_B=$((${VM_QUOTA_SYSTEM_DISK_UNALLOCATED_MB}*1024*1024))
        elif [ $VM_QUOTA_SYSTEM_DISK_ALLOCATED_MB -eq 1 ];
          then
            VM_QUOTA_SYSTEM_DISK_UNALLOCATED_B=$((${VM_QUOTA_SYSTEM_DISK_UNALLOCATED_MB}*1024*1024))
        else
          VM_QUOTA_SYSTEM_DISK_UNALLOCATED_MB=$((${VM_QUOTA_SYSTEM_DISK_SIZE_MB}-${VM_QUOTA_SYSTEM_DISK_ALLOCATED_MB}))
          VM_QUOTA_SYSTEM_DISK_UNALLOCATED_B=$((${VM_QUOTA_SYSTEM_DISK_UNALLOCATED_MB}*1024*1024))
      fi
  fi  
}

# Body script
case $1 in
  HOST-KVM)
    host_id=$2
    case $3 in
      TOTAL_MEM_B)
        get_host_total_mem
        echo $TOTAL_MEM_B
        ## Exiting from script
        exit 0
        ;;
      ALLOCATED_MEM_B)
        get_host_allocated_mem
        echo $ALLOCATED_MEM_B
        ## Exiting from script
        exit 0
        ;;
      REAL_FREE_MEM_B)
        get_orch_status
        ## If is the leader, then...
        get_host_real_free_mem
        echo $REAL_FREE_MEM_B
        ## Exiting from script
        exit 0
        ;;
      REAL_USED_MEM_B)
        get_orch_status
        ## If is the leader, then...
        get_host_real_used_mem
        echo $REAL_USED_MEM_B
        ## Exiting from script
        exit 0
        ;;
      UNALLOCATED_MEM_B)
        get_host_unallocated_mem
        echo $UNALLOCATED_MEM_B
        ## Exiting from script
        exit 0
        ;;
      ALLOCATED_MEM_PERCENT)
        get_host_allocated_mem_percent
        echo $ALLOCATED_MEM_PERCENT
        ## Exiting from script
        exit 0
        ;;
      REAL_USED_MEM_PERCENT)
        get_orch_status
        get_host_real_used_mem_percent
        echo $REAL_USED_MEM_PERCENT
        ## Exiting from script
        exit 0
        ;;
      TOTAL_CPU)
        get_host_total_cpu
        echo $TOTAL_CPU
        ## Exiting from script
        exit 0
        ;;
      ALLOCATED_CPU)
        get_host_allocated_cpu
        echo $ALLOCATED_CPU
        ## Exiting from script
        exit 0
        ;;
      REAL_FREE_CPU)
        get_orch_status
        ## If is the leader, then...
        get_host_real_free_cpu
        echo $REAL_FREE_CPU
        ## Exiting from script
        exit 0
        ;;
      REAL_USED_CPU)
        get_orch_status
        ## If is the leader, then...
        get_host_real_used_cpu
        echo $REAL_USED_CPU
        ## Exiting from script
        exit 0
        ;;
      UNALLOCATED_CPU)
        get_host_unallocated_cpu
        echo $UNALLOCATED_CPU
        ## Exiting from script
        exit 0
        ;;
      ALLOCATED_CPU_PERCENT)
        get_host_allocated_cpu_percent
        echo $ALLOCATED_CPU_PERCENT
        ## Exiting from script
        exit 0
        ;;
      REAL_USED_CPU_PERCENT)
        get_orch_status
        get_host_real_used_cpu_percent
        echo $REAL_USED_CPU_PERCENT
        ## Exiting from script
        exit 0
        ;;
      TOTAL_VM)
        get_host_total_vm
        echo $TOTAL_VM
        ## Exiting from script
        exit 0
        ;;
      RUNN_VM)
        get_host_runn_vm
        echo $RUNN_VM
        ## Exiting from script
        exit 0
        ;;
      POFF_VM)
        get_host_poff_vm
        echo $POFF_VM
        ## Exiting from script
        exit 0
        ;;
      FAIL_VM)
        get_host_fail_vm
        echo $FAIL_VM
        ## Exiting from script
        exit 0
        ;;
      UNKN_VM)
        get_host_unkn_vm
        echo $UNKN_VM
        ## Exiting from script
        exit 0
        ;;
      --help|-h)
        help_host
        ## Exiting from script
        exit 0
        ;;
      *)
        help_host
        ## Exiting from script
        exit 0
        ;;
    esac
    ;;
  CLUSTER-KVM)
    case $2 in
      TOTAL_MEM_B)
        get_cluster-kvm_members_id
        tmpdir=/tmp/bashone
        tmpfile=$tmpdir/HOSTKVMID_for_CLUSTER-KVM_TOTAL_MEM_B
        check_tmp_file
        tmpfile=$tmpdir/host-kvm_total_mem_for_CLUSTER-KVM_TOTAL_MEM_B
        check_tmp_file
        tmpfile=$tmpdir/HOSTKVMID
        tmpfile2=$tmpdir/host-kvm_total_mem_for_CLUSTER-KVM_TOTAL_MEM_B
        if [ $count -eq 1 ];
          then
            host_id=$id
            get_host_total_mem
            echo $TOTAL_MEM_B
            ## Exiting from script
            exit 0
          else
            for i in "${id[@]}"
              do
                host_id=$i
                get_host_total_mem
                echo $TOTAL_MEM_B >> $tmpfile2
            done
            cat $tmpfile2 | paste -sd+ - | bc
        fi
        ## Exiting from script
        exit 0
        ;;
      ALLOCATED_MEM_B)
        get_cluster-kvm_members_id
        tmpdir=/tmp/bashone
        tmpfile=$tmpdir/HOSTKVMID_for_CLUSTER-KVM_ALLOCATED_MEM_B
        check_tmp_file
        tmpfile=$tmpdir/host-kvm_allocated_mem_for_CLUSTER-KVM_ALLOCATED_MEM_B
        check_tmp_file
        tmpfile=$tmpdir/HOSTKVMID_for_CLUSTER-KVM_ALLOCATED_MEM_B
        tmpfile2=$tmpdir/host-kvm_allocated_mem_for_CLUSTER-KVM_ALLOCATED_MEM_B
        if [ $count -eq 1 ];
          then
            host_id=$id
            get_host_allocated_mem
            echo $ALLOCATED_MEM_B
            ## Exiting from script
            exit 0
          else
            for i in "${id[@]}"
              do
                host_id=$i
                get_host_allocated_mem
                echo $ALLOCATED_MEM_B >> $tmpfile2
            done
            cat $tmpfile2 | paste -sd+ - | bc
        fi
        ## Exiting from script
        exit 0
        ;;
      REAL_FREE_MEM_B)
        get_orch_status
        ## If is the leader, then...
        get_cluster-kvm_members_id
        tmpdir=/tmp/bashone
        tmpfile=$tmpdir/HOSTKVMID_for_CLUSTER-KVM_REAL_FREE_MEM_B
        check_tmp_file
        tmpfile=$tmpdir/host-kvm_real_free_mem_for_CLUSTER-KVM_REAL_FREE_MEM_B
        check_tmp_file
        tmpfile=$tmpdir/HOSTKVMID_for_CLUSTER-KVM_REAL_FREE_MEM_B
        tmpfile2=$tmpdir/host-kvm_real_free_mem_for_CLUSTER-KVM_REAL_FREE_MEM_B
        if [ $count -eq 1 ];
          then
            host_id=$id
            get_host_real_free_mem
            echo $REAL_FREE_MEM_B
            ## Exiting from script
            exit 0
          else
            ## There are more than one host and the required info needs to be calculated for each one
            for i in "${id[@]}"
              do
                host_id=$i
                get_host_real_free_mem
                echo $REAL_FREE_MEM_B >> $tmpfile2
            done
            cat $tmpfile2 | paste -sd+ - | bc
        fi
        ## Exiting from script
        exit 0
        ;;
      REAL_USED_MEM_B)
        get_orch_status
        ## If is the leader, then...
        get_cluster-kvm_members_id
        tmpdir=/tmp/bashone
        tmpfile=$tmpdir/HOSTKVMID_for_CLUSTER-KVM_REAL_USED_MEM_B
        check_tmp_file
        tmpfile=$tmpdir/host-kvm_real_used_mem_for_CLUSTER-KVM_REAL_USED_MEM_B
        check_tmp_file
        tmpfile=$tmpdir/HOSTKVMID_for_CLUSTER-KVM_REAL_USED_MEM_B
        tmpfile2=$tmpdir/host-kvm_real_used_mem_for_CLUSTER-KVM_REAL_USED_MEM_B
        if [ $count -eq 1 ];
          then
            host_id=$id
            get_host_real_used_mem
            echo $REAL_USED_MEM_B
            ## Exiting from script
            exit 0
          else
            ## There are more than one host and the required info needs to be calculated for each one
            for i in "${id[@]}"
              do
                host_id=$i
                get_host_real_used_mem
                echo $REAL_USED_MEM_B >> $tmpfile2
            done
            cat $tmpfile2 | paste -sd+ - | bc
        fi
        ## Exiting from script
        exit 0
        ;;
      UNALLOCATED_MEM_B)
        get_cluster-kvm_members_id
        tmpdir=/tmp/bashone
        tmpfile=$tmpdir/HOSTKVMID_for_CLUSTER-KVM_UNALLOCATED_MEM_B
        check_tmp_file
        tmpfile=$tmpdir/host-kvm_unallocated_mem_for_CLUSTER-KVM_UNALLOCATED_MEM_B
        check_tmp_file
        tmpfile=$tmpdir/HOSTKVMID_for_CLUSTER-KVM_UNALLOCATED_MEM_B
        tmpfile2=$tmpdir/host-kvm_unallocated_mem_for_CLUSTER-KVM_UNALLOCATED_MEM_B
        if [ $count -eq 1 ];
          then
            host_id=$id
            get_host_unallocated_mem
            echo $UNALLOCATED_MEM_B
            ## Exiting from script
            exit 0
          else
            for i in "${id[@]}"
              do
                host_id=$i
                get_host_unallocated_mem
                echo $UNALLOCATED_MEM_B >> $tmpfile2
            done
            cat $tmpfile2 | paste -sd+ - | bc
        fi
        ## Exiting from script
        exit 0
        ;;
      ALLOCATED_MEM_PERCENT)
        ## percent=(P/T)*100
        ## Calculating TOTAL_MEM
        get_cluster-kvm_members_id
        tmpdir=/tmp/bashone
        tmpfile=$tmpdir/HOSTKVMID_for_CLUSTER-KVM_ALLOCATED_MEM_PERCENT_T
        check_tmp_file
        tmpfile=$tmpdir/host-kvm_total_mem_for_CLUSTER-KVM_ALLOCATED_MEM_PERCENT_T
        check_tmp_file
        tmpfile=$tmpdir/HOSTKVMID_for_CLUSTER-KVM_ALLOCATED_MEM_PERCENT_T
        tmpfile2=$tmpdir/host-kvm_total_mem_for_CLUSTER-KVM_ALLOCATED_MEM_PERCENT_T
        if [ $count -eq 1 ];
          then
            host_id=$id
            get_host_total_mem
          else
            for i in "${id[@]}"
              do
                host_id=$i
                get_host_total_mem
                echo $TOTAL_MEM_B >> $tmpfile2
            done
            TOTAL_MEM_B=$(cat $tmpfile2 | paste -sd+ - | bc)
        fi
        ## Calculating ALLOCATED_MEM
        tmpfile=$tmpdir/HOSTKVMID_for_CLUSTER-KVM_ALLOCATED_MEM_PERCENT_P
        check_tmp_file
        tmpfile=$tmpdir/host-kvm_allocated_mem_for_CLUSTER-KVM_ALLOCATED_MEM_PERCENT_P
        check_tmp_file
        tmpfile=$tmpdir/HOSTKVMID_for_CLUSTER-KVM_ALLOCATED_MEM_PERCENT_P
        tmpfile2=$tmpdir/host-kvm_allocated_mem_for_CLUSTER-KVM_ALLOCATED_MEM_PERCENT_P
        if [ $count -eq 1 ];
          then
            host_id=$id
            get_host_allocated_mem
          else
            for i in "${id[@]}"
              do
                host_id=$i
                get_host_allocated_mem
                echo $ALLOCATED_MEM_B >> $tmpfile2
            done
            ALLOCATED_MEM_B=$(cat $tmpfile2 | paste -sd+ - | bc)
        fi
        ## Calculating ALLOCATED_MEM_PERCENT
        P=$ALLOCATED_MEM_B
        T=$TOTAL_MEM_B
        D=$(echo "scale=2 ; $P / $T" | bc)
        float=$(expr $D*100 | bc)
        echo "$(float_to_int)"
        ## Exiting from script
        exit 0
        ;;
      REAL_USED_MEM_PERCENT)
        get_orch_status
        ## percent=(P/T)*100
        ## Calculating TOTAL_MEM
        get_cluster-kvm_members_id
        tmpdir=/tmp/bashone
        tmpfile=$tmpdir/HOSTKVMID_for_CLUSTER-KVM_REAL_USED_MEM_PERCENT_T
        check_tmp_file
        tmpfile=$tmpdir/host-kvm_total_mem_for_CLUSTER-KVM_REAL_USED_MEM_PERCENT_T
        check_tmp_file
        tmpfile=$tmpdir/HOSTKVMID_for_CLUSTER-KVM_REAL_USED_MEM_PERCENT_T
        tmpfile2=$tmpdir/host-kvm_total_mem_for_CLUSTER-KVM_REAL_USED_MEM_PERCENT_T
        if [ $count -eq 1 ];
          then
            host_id=$id
            get_host_total_mem
          else
            for i in "${id[@]}"
              do
                host_id=$i
                get_host_total_mem
                echo $TOTAL_MEM_B >> $tmpfile2
            done
            TOTAL_MEM_B=$(cat $tmpfile2 | paste -sd+ - | bc)
        fi
        ## Calculating REAL_USED_MEM
        tmpfile=$tmpdir/HOSTKVMID_for_CLUSTER-KVM_REAL_USED_MEM_PERCENT_P
        check_tmp_file
        tmpfile=$tmpdir/host-kvm_real_used_mem_for_CLUSTER-KVM_REAL_USED_MEM_PERCENT_P
        check_tmp_file
        tmpfile=$tmpdir/HOSTKVMID_for_CLUSTER-KVM_REAL_USED_MEM_PERCENT_P
        tmpfile2=$tmpdir/host-kvm_real_used_mem_for_CLUSTER-KVM_REAL_USED_MEM_PERCENT_P
        if [ $count -eq 1 ];
          then
            host_id=$id
            get_host_real_used_mem
          else
            for i in "${id[@]}"
              do
                host_id=$i
                get_host_real_used_mem
                echo $REAL_USED_MEM_B >> $tmpfile2
            done
            REAL_USED_MEM_B=$(cat $tmpfile2 | paste -sd+ - | bc)
        fi
        ## Calculating REAL_USED_MEM_PERCENT
        P=$REAL_USED_MEM_B
        T=$TOTAL_MEM_B
        D=$(echo "scale=2 ; $P / $T" | bc)
        float=$(expr $D*100 | bc)
        echo "$(float_to_int)"
        ## Exiting from script
        exit 0
        ;;
      TOTAL_CPU)
        get_cluster-kvm_members_id
        tmpdir=/tmp/bashone
        tmpfile=$tmpdir/HOSTKVMID_for_CLUSTER-KVM_TOTAL_CPU
        check_tmp_file
        tmpfile=$tmpdir/host-kvm_total_cpu_for_CLUSTER-KVM_TOTAL_CPU
        check_tmp_file
        tmpfile=$tmpdir/HOSTKVMID_for_CLUSTER-KVM_TOTAL_CPU
        tmpfile2=$tmpdir/host-kvm_total_cpu_for_CLUSTER-KVM_TOTAL_CPU
        if [ $count -eq 1 ];
          then
            host_id=$id
            get_host_total_cpu
            echo $TOTAL_CPU
            ## Exiting from script
            exit 0
          else
            for i in "${id[@]}"
              do
                host_id=$i
                get_host_total_cpu
                echo $TOTAL_CPU >> $tmpfile2
            done
            cat $tmpfile2 | paste -sd+ - | bc
        fi
        ## Exiting from script
        exit 0
        ;;
      ALLOCATED_CPU)
        get_cluster-kvm_members_id
        tmpdir=/tmp/bashone
        tmpfile=$tmpdir/HOSTKVMID_for_CLUSTER-KVM_TOTAL_CPU
        check_tmp_file
        tmpfile=$tmpdir/host-kvm_allocated_cpu_for_CLUSTER-KVM_TOTAL_CPU
        check_tmp_file
        tmpfile=$tmpdir/HOSTKVMID_for_CLUSTER-KVM_TOTAL_CPU
        tmpfile2=$tmpdir/host-kvm_allocated_cpu_for_CLUSTER-KVM_TOTAL_CPU
        if [ $count -eq 1 ];
          then
            host_id=$id
            get_host_allocated_cpu
            echo $ALLOCATED_CPU
            ## Exiting from script
            exit 0
          else
            for i in "${id[@]}"
              do
                host_id=$i
                get_host_allocated_cpu
                echo $ALLOCATED_CPU >> $tmpfile2
            done
            cat $tmpfile2 | paste -sd+ - | bc
        fi
        ## Exiting from script
        exit 0
        ;;
      REAL_FREE_CPU)
        get_orch_status
        ## If is the leader, then...
        get_cluster-kvm_members_id
        tmpdir=/tmp/bashone
        tmpfile=$tmpdir/HOSTKVMID_for_CLUSTER-KVM_REAL_FREE_CPU
        check_tmp_file
        tmpfile=$tmpdir/host-kvm_real_free_cpu_for_CLUSTER-KVM_REAL_FREE_CPU
        check_tmp_file
        tmpfile=$tmpdir/HOSTKVMID_for_CLUSTER-KVM_REAL_FREE_CPU
        tmpfile2=$tmpdir/host-kvm_real_free_cpu_for_CLUSTER-KVM_REAL_FREE_CPU
        if [ $count -eq 1 ];
          then
            host_id=$id
            get_host_real_free_cpu
            echo $REAL_FREE_CPU
            ## Exiting from script
            exit 0
          else
            ## There are more than one host and the required info needs to be calculated for each one
            for i in "${id[@]}"
              do
                host_id=$i
                get_host_real_free_cpu
                echo $REAL_FREE_CPU >> $tmpfile2
            done
            cat $tmpfile2 | paste -sd+ - | bc
        fi
        ## Exiting from script
        exit 0
        ;;
      REAL_USED_CPU)
        get_orch_status
        ## If is the leader, then...
        get_cluster-kvm_members_id
        tmpdir=/tmp/bashone
        tmpfile=$tmpdir/HOSTKVMID_for_CLUSTER-KVM_REAL_USED_CPU
        check_tmp_file
        tmpfile=$tmpdir/host-kvm_real_used_cpu_for_CLUSTER-KVM_REAL_USED_CPU
        check_tmp_file
        tmpfile=$tmpdir/HOSTKVMID_for_CLUSTER-KVM_REAL_USED_CPU
        tmpfile2=$tmpdir/host-kvm_real_used_cpu_for_CLUSTER-KVM_REAL_USED_CPU
        if [ $count -eq 1 ];
          then
            host_id=$id
            get_host_real_used_cpu
            echo $REAL_USED_CPU
            ## Exiting from script
            exit 0
          else
            ## There are more than one host and the required info needs to be calculated for each one
            for i in "${id[@]}"
              do
                host_id=$i
                get_host_real_used_cpu
                echo $REAL_USED_CPU >> $tmpfile2
            done
            cat $tmpfile2 | paste -sd+ - | bc
        fi
        ## Exiting from script
        exit 0
        ;;
      UNALLOCATED_CPU)
        get_cluster-kvm_members_id
        tmpdir=/tmp/bashone
        tmpfile=$tmpdir/HOSTKVMID_for_CLUSTER-KVM_UNALLOCATED_CPU
        check_tmp_file
        tmpfile=$tmpdir/host-kvm_unallocated_cpu_for_CLUSTER-KVM_UNALLOCATED_CPU
        check_tmp_file
        tmpfile=$tmpdir/HOSTKVMID_for_CLUSTER-KVM_UNALLOCATED_CPU
        tmpfile2=$tmpdir/host-kvm_unallocated_cpu_for_CLUSTER-KVM_UNALLOCATED_CPU
        if [ $count -eq 1 ];
          then
            host_id=$id
            get_host_unallocated_cpu
            echo $UNALLOCATED_CPU
            ## Exiting from script
            exit 0
          else
            for i in "${id[@]}"
              do
                host_id=$i
                get_host_unallocated_cpu
                echo $UNALLOCATED_CPU >> $tmpfile2
            done
            cat $tmpfile2 | paste -sd+ - | bc
        fi
        ## Exiting from script
        exit 0
        ;;
      ALLOCATED_CPU_PERCENT)
        ## percent=(P/T)*100
        ## Calculating TOTAL_CPU
        get_cluster-kvm_members_id
        tmpdir=/tmp/bashone
        tmpfile=$tmpdir/HOSTKVMID_for_CLUSTER-KVM_ALLOCATED_CPU_PERCENT_T
        check_tmp_file
        tmpfile=$tmpdir/host-kvm_total_cpu_for_CLUSTER-KVM_ALLOCATED_CPU_PERCENT_T
        check_tmp_file
        tmpfile=$tmpdir/HOSTKVMID_for_CLUSTER-KVM_ALLOCATED_CPU_PERCENT_T
        tmpfile2=$tmpdir/host-kvm_total_cpu_for_CLUSTER-KVM_ALLOCATED_CPU_PERCENT_T
        if [ $count -eq 1 ];
          then
            host_id=$id
            get_host_total_cpu
          else
            for i in "${id[@]}"
              do
                host_id=$i
                get_host_total_cpu
                echo $TOTAL_CPU >> $tmpfile2
            done
            TOTAL_CPU=$(cat $tmpfile2 | paste -sd+ - | bc)
        fi
        ## Calculating ALLOCATED_CPU
        tmpfile=$tmpdir/HOSTKVMID_for_CLUSTER-KVM_ALLOCATED_CPU_PERCENT_P
        check_tmp_file
        tmpfile=$tmpdir/host-kvm_total_cpu_for_CLUSTER-KVM_ALLOCATED_CPU_PERCENT_P
        check_tmp_file
        tmpfile=$tmpdir/HOSTKVMID_for_CLUSTER-KVM_ALLOCATED_CPU_PERCENT_P
        tmpfile2=$tmpdir/host-kvm_total_cpu_for_CLUSTER-KVM_ALLOCATED_CPU_PERCENT_P
        if [ $count -eq 1 ];
          then
            host_id=$id
            get_host_allocated_cpu
          else
            for i in "${id[@]}"
              do
                host_id=$i
                get_host_allocated_cpu
                echo $ALLOCATED_CPU >> $tmpfile2
            done
            ALLOCATED_CPU=$(cat $tmpfile2 | paste -sd+ - | bc)
        fi
        ## Calculating ALLOCATED_CPU_PERCENT
        P=$ALLOCATED_CPU
        T=$TOTAL_CPU
        D=$(echo "scale=2 ; $P / $T" | bc)
        float=$(expr $D*100 | bc)
        echo "$(float_to_int)"
        ## Exiting from script
        exit 0
        ;;
      REAL_USED_CPU_PERCENT)
        get_orch_status
        ## percent=(P/T)*100
        ## Calculating TOTAL_CPU
        get_cluster-kvm_members_id
        tmpdir=/tmp/bashone
        tmpfile=$tmpdir/HOSTKVMID_for_CLUSTER-KVM_REAL_USED_CPU_PERCENT_T
        check_tmp_file
        tmpfile=$tmpdir/host-kvm_total_cpu_for_CLUSTER-KVM_REAL_USED_CPU_PERCENT_T
        check_tmp_file
        tmpfile=$tmpdir/HOSTKVMID_for_CLUSTER-KVM_REAL_USED_CPU_PERCENT_T
        tmpfile2=$tmpdir/host-kvm_total_cpu_for_CLUSTER-KVM_REAL_USED_CPU_PERCENT_T
        if [ $count -eq 1 ];
          then
            host_id=$id
            get_host_total_cpu
          else
            for i in "${id[@]}"
              do
                host_id=$i
                get_host_total_cpu
                echo $TOTAL_CPU >> $tmpfile2
            done
            TOTAL_CPU=$(cat $tmpfile2 | paste -sd+ - | bc)
        fi
        ## Calculating REAL_USED_CPU
        tmpfile=$tmpdir/HOSTKVMID_for_CLUSTER-KVM_REAL_USED_CPU_PERCENT_P
        check_tmp_file
        tmpfile=$tmpdir/host-kvm_total_cpu_for_CLUSTER-KVM_REAL_USED_CPU_PERCENT_P
        check_tmp_file
        tmpfile=$tmpdir/HOSTKVMID_for_CLUSTER-KVM_REAL_USED_CPU_PERCENT_P
        tmpfile2=$tmpdir/host-kvm_total_cpu_for_CLUSTER-KVM_REAL_USED_CPU_PERCENT_P
        if [ $count -eq 1 ];
          then
            host_id=$id
            get_host_real_used_cpu
          else
            for i in "${id[@]}"
              do
                host_id=$i
                get_host_real_used_cpu
                echo $REAL_USED_CPU >> $tmpfile2
            done
            REAL_USED_CPU=$(cat $tmpfile2 | paste -sd+ - | bc)
        fi
        ## Calculating REAL_USED_CPU_PERCENT
        P=$REAL_USED_CPU
        T=$TOTAL_CPU
        D=$(echo "scale=2 ; $P / $T" | bc)
        float=$(expr $D*100 | bc)
        echo "$(float_to_int)"
        ## Exiting from script
        exit 0
        ;;
      TOTAL_VM)
        get_cluster_total_vm
        echo $TOTAL_VM
        ## Exiting from script
        exit 0
        ;;
      RUNN_VM)
        get_cluster_runn_vm
        echo $RUNN_VM
        ## Exiting from script
        exit 0
        ;;
      POFF_VM)
        get_cluster_poff_vm
        echo $POFF_VM
        ## Exiting from script
        exit 0
        ;;
      FAIL_VM)
        get_cluster_fail_vm
        echo $FAIL_VM
        ## Exiting from script
        exit 0
        ;;
      UNKN_VM)
        get_cluster_unkn_vm
        echo $UNKN_VM
        ## Exiting from script
        exit 0
        ;;
      --help|-h)
        help_cluster
        ## Exiting from script
        exit 0
        ;;
      *)
        help_cluster
        ## Exiting from script
        exit 0
        ;;
    esac
    ;;
  DATASTORE)
    datastore_id=$2
    case $3 in
      TOTAL_SIZE_B)
        get_datastore_total_size
        echo $TOTAL_SIZE_B
        ## Exiting from script
        exit 0
        ;;
      REAL_FREE_SIZE_B)
        get_datastore_real_free_size
        echo $REAL_FREE_SIZE_B
        ## Exiting from script
        exit 0
        ;;
      REAL_USED_SIZE_B)
        get_datastore_real_used_size
        echo $REAL_USED_SIZE_B
        ## Exiting from script
        exit 0
        ;;
      ALLOCATED_SIZE_B)
        get_orch_status
        ## If is the leader, then...
        ## VM ALLOCATED SIZE
        vm_list=$(echo $(onevm list | egrep "pend|hold|clon|prol|boot|runn|migr|hotp|snap|save|epil|shut|stop|susp|poff|unde|fail|unkn|clea|done" | awk '{print $1}'))
        vm_id=(`echo $vm_list | tr ' ' ' '`)
        tmpdir=/tmp/bashone
        tmpfile=$tmpdir/vm_allocated_disk_size_for_CLUSTER-KVM_ALLOCATED_SIZE_B
        tmpfile2=$tmpdir/vm_allocated_disk_size_tmp_for_CLUSTER-KVM_ALLOCATED_SIZE_B
        ### Delete "tmpfile" if older than 120min
        ### Means that script will recalculate the allocated TOTAL_VM_ALLOCATED_DISK_SIZE_B
        LOCATION=$tmpdir
        REQUIRED_FILE=$(echo $tmpfile | awk -F "/" '{print $NF}')
        if [ ! -z $REQUIRED_FILE ];
          then
            ## You can use this, using vars
            #find $LOCATION -name $REQUIRED_FILE -type f -mmin +120 -delete
            ## Or this. Better be precautious when there is a delete action.
            find /tmp/bashone -name vm_allocated_disk_size_for_CLUSTER-KVM_ALLOCATED_SIZE_B -type f -mmin +120 -delete
        fi

        ### As maximun execution time for Zabbix script is 30s, and there could be many "vm", 
        ### the script could take more than this time to gather the required "allocated vm space".
        ### One solution for this could be execute the script and read first the tmp file with previous
        ### calculation results. It doesn't matter if zabbix script reach the timeout limit, script will
        ### continue in background.
        if [ -s $tmpfile ];
          then
            ##### Print total space allocated by VM vdisk, from last time script execution
            TOTAL_VM_ALLOCATED_DISK_SIZE_B=$(cat $tmpfile | paste -sd+ - | bc)
          else
            ##### File is empty
            for i in "${vm_id[@]}"
              do
                get_allocated_vdisk_size
                echo $VM_ALLOCATED_DISK_SIZE_B >> $tmpfile2
            done
            ##### Print total space allocated by VM vdisks
            cp $tmpfile2 $tmpfile
            cat /dev/null > $tmpfile2
            TOTAL_VM_ALLOCATED_DISK_SIZE_B=$(cat $tmpfile | paste -sd+ - | bc)
        fi

        #### IMAGE ALLOCATED SIZE
        get_allocated_img_size

        ### Finally, the ~ datastore allocated size in Bytes
        ALLOCATED_SIZE_B=$(awk "BEGIN{ print ${TOTAL_VM_ALLOCATED_DISK_SIZE_B} + ${TOTAL_IMG_ALLOCATED_SIZE_B} }")
        echo $ALLOCATED_SIZE_B
        ## Exiting from script
        exit 0
        ;;
      UNALLOCATED_SIZE_B)
        get_orch_status
        ## If is the leader, then...
        ## VM ALLOCATED SIZE
        vm_list=$(echo $(onevm list | egrep "pend|hold|clon|prol|boot|runn|migr|hotp|snap|save|epil|shut|stop|susp|poff|unde|fail|unkn|clea|done" | awk '{print $1}'))
        vm_id=(`echo $vm_list | tr ' ' ' '`)
        tmpdir=/tmp/bashone
        tmpfile=$tmpdir/vm_allocated_disk_size_for_CLUSTER-KVM_ALLOCATED_SIZE_B
        if [ -s $tmpfile ];
          then
            ### Total space allocated by VM vdisks, from last time script execution
            TOTAL_VM_ALLOCATED_DISK_SIZE_B=$(cat $tmpfile | paste -sd+ - | bc)
            ### Total space allocated by images
            get_allocated_img_size

            ### Finally, the ~ datastore unallocated size in Bytes
            get_datastore_total_size
            ALLOCATED_SIZE_B=$(awk "BEGIN{ print ${TOTAL_VM_ALLOCATED_DISK_SIZE_B} + ${TOTAL_IMG_ALLOCATED_SIZE_B} }")
            UNALLOCATED_SIZE_B=$(awk "BEGIN{ print ${TOTAL_SIZE_B} - ${ALLOCATED_SIZE_B} }")
            echo $UNALLOCATED_SIZE_B
          else
            tmpfile=$tmpdir/vm_allocated_disk_size_for_CLUSTER-KVM_UNALLOCATED_SIZE_B
            tmpfile2=$tmpdir/vm_allocated_disk_size_tmp_for_CLUSTER-KVM_UNALLOCATED_SIZE_B
            ### Delete "tmpfile" if older than 120min
            ### Means that script will recalculate the allocated TOTAL_VM_ALLOCATED_DISK_SIZE_B
            LOCATION=$tmpdir
            REQUIRED_FILE=$(echo $tmpfile | awk -F "/" '{print $NF}')
            if [ ! -z $REQUIRED_FILE ];
              then
                ## You can use this, using vars
                #find $LOCATION -name $REQUIRED_FILE -type f -mmin +120 -delete
                ## Or this. Better be precautious when there is a delete action.
                find /tmp/bashone -name vm_allocated_disk_size_for_CLUSTER-KVM_UNALLOCATED_SIZE_B -type f -mmin +120 -delete
            fi

            ### As maximun execution time for Zabbix script is 30s, and there could be many "vm", 
            ### the script could take more than this time to gather the required "allocated vm space".
            ### One solution for this could be execute the script and read first the tmp file with previous
            ### calculation results. It doesn't matter if zabbix script reach the timeout limit, script will
            ### continue in background.
            if [ -s $tmpfile ];
              then
                ##### Print total space allocated by VM vdisks, from last time script execution
                TOTAL_VM_ALLOCATED_DISK_SIZE_B=$(cat $tmpfile | paste -sd+ - | bc)
              else
                ##### File is empty
                for i in "${vm_id[@]}"
                  do
                    get_allocated_vdisk_size
                    echo $VM_ALLOCATED_DISK_SIZE_B >> $tmpfile2
                done
                ##### Print total space allocated by VM vdisks
                cp $tmpfile2 $tmpfile
                cat /dev/null > $tmpfile2
                TOTAL_VM_ALLOCATED_DISK_SIZE_B=$(cat $tmpfile | paste -sd+ - | bc)
            fi

            #### IMAGE ALLOCATED SIZE
            get_allocated_img_size

            ### Finally, the ~ datastore unallocated size in Bytes
            get_datastore_total_size
            ALLOCATED_SIZE_B=$(awk "BEGIN{ print ${TOTAL_VM_ALLOCATED_DISK_SIZE_B} + ${TOTAL_IMG_ALLOCATED_SIZE_B} }")
            UNALLOCATED_SIZE_B=$(awk "BEGIN{ print ${TOTAL_SIZE_B} - ${ALLOCATED_SIZE_B} }")
            echo $UNALLOCATED_SIZE_B
        fi
        ## Exiting from script
        exit 0
        ;;
      ALLOCATED_SIZE_PERCENT)
        get_orch_status
        ## If is the leader, then...

        ## Calculating TOTAL_SIZE_B
        get_datastore_total_size

        ## VM ALLOCATED SIZE
        vm_list=$(echo $(onevm list | egrep "pend|hold|clon|prol|boot|runn|migr|hotp|snap|save|epil|shut|stop|susp|poff|unde|fail|unkn|clea|done" | awk '{print $1}'))
        vm_id=(`echo $vm_list | tr ' ' ' '`)
        tmpdir=/tmp/bashone
        tmpfile=$tmpdir/vm_allocated_disk_size_for_CLUSTER-KVM_ALLOCATED_SIZE_B
        tmpfile2=$tmpdir/vm_allocated_disk_size_tmp_for_CLUSTER-KVM_ALLOCATED_SIZE_B
        ### Delete "tmpfile" if older than 120min
        ### Means that script will recalculate the allocated TOTAL_VM_ALLOCATED_DISK_SIZE_B
        LOCATION=$tmpdir
        REQUIRED_FILE=$(echo $tmpfile | awk -F "/" '{print $NF}')
        if [ ! -z $REQUIRED_FILE ];
          then
            ## You can use this, using vars
            #find $LOCATION -name $REQUIRED_FILE -type f -mmin +120 -delete
            ## Or this. Better be precautious when there is a delete action.
            find /tmp/bashone -name vm_allocated_disk_size_for_CLUSTER-KVM_ALLOCATED_SIZE_B -type f -mmin +120 -delete
        fi

        ### As maximun execution time for Zabbix script is 30s, and there could be many "vm", 
        ### the script could take more than this time to gather the required "allocated vm space".
        ### One solution for this could be execute the script and read first the tmp file with previous
        ### calculation results. It doesn't matter if zabbix script reach the timeout limit, script will
        ### continue in background.
        if [ -s $tmpfile ];
          then
            ##### Print total space allocated by images, from last time script execution
            TOTAL_VM_ALLOCATED_DISK_SIZE_B=$(cat $tmpfile | paste -sd+ - | bc)
          else
            ##### File is empty
            for i in "${vm_id[@]}"
              do
                get_allocated_vdisk_size
                echo $VM_ALLOCATED_DISK_SIZE_B >> $tmpfile2
            done
            ##### Print total space allocated by VM vdisks
            cp $tmpfile2 $tmpfile
            cat /dev/null > $tmpfile2
            TOTAL_VM_ALLOCATED_DISK_SIZE_B=$(cat $tmpfile | paste -sd+ - | bc)
        fi

        #### IMAGE ALLOCATED SIZE
        get_allocated_img_size

        ### Finally, the ~ datastore allocated size in Bytes
        ALLOCATED_SIZE_B=$(awk "BEGIN{ print ${TOTAL_VM_ALLOCATED_DISK_SIZE_B} + ${TOTAL_IMG_ALLOCATED_SIZE_B} }")

        ## percent=(P/T)*100
        T=$TOTAL_SIZE_B
        P=$ALLOCATED_SIZE_B
        D=$(echo "scale=2 ; $P / $T" | bc)
        float=$(expr $D*100 | bc)
        ALLOCATED_SIZE_PERCENT=$(echo "$(float_to_int)")
        echo $ALLOCATED_SIZE_PERCENT

        ## Exiting from script
        exit 0
        ;;
      --help|-h)
        help_datastore
        ## Exiting from script
        exit 0
        ;;
      *)
        help_datastore
        ## Exiting from script
        exit 0
        ;;
    esac
    ;;
  IMAGE)
    case $2 in
      TOTAL_IMAGE)
        get_image_total_img
        echo $TOTAL_IMAGE
        ## Exiting from script
        exit 0
        ;;
      RDY_IMAGE)
        get_image_rdy_img
        echo $RDY_IMAGE
        ## Exiting from script
        exit 0
        ;;
      USED_IMAGE)
        get_image_used_img
        echo $USED_IMAGE
        ## Exiting from script
        exit 0
        ;;
      ERR_IMAGE)
        get_image_err_img
        echo $ERR_IMAGE
        ## Exiting from script
        exit 0
        ;;
      LOCK_IMAGE)
        get_image_lock_img
        echo $LOCK_IMAGE
        ## Exiting from script
        exit 0
        ;;
      --help|-h)
        help_image
        ## Exiting from script
        exit 0
        ;;
      *)
        help_image
        ## Exiting from script
        exit 0
        ;;
    esac
    ;;
  VNET)
    vnet_id=$2
    case $3 in
      POOL_SIZE)
        get_pool_size
        echo $POOL_SIZE
        ## Exiting from script
        exit 0
        ;;
      ALLOCATED_IP)
        get_allocated_ip
        echo $ALLOCATED_IP
        ## Exiting from script
        exit 0
        ;;
      UNALLOCATED_IP)
        get_unallocated_ip
        echo $UNALLOCATED_IP
        ## Exiting from script
        exit 0
        ;;
      --help|-h)
        help_vnet
        ## Exiting from script
        exit 0
        ;;
      *)
        help_vnet
        ## Exiting from script
        exit 0
        ;;
    esac
    ;;
  GROUP)
    group_id=$2
    case $3 in
      VM_QUOTA_TOTAL_MEM_B)
        get_group_vm_quota_total_mem
        echo $VM_QUOTA_TOTAL_MEM_B
        ## Exiting from script
        exit 0
        ;;
      VM_QUOTA_ALLOCATED_MEM_B)
        get_group_vm_quota_allocated_mem
        echo $VM_QUOTA_ALLOCATED_MEM_B
        ## Exiting from script
        exit 0
        ;;
      VM_QUOTA_UNALLOCATED_MEM_B)
        get_group_vm_quota_unallocated_mem
        echo $VM_QUOTA_UNALLOCATED_MEM_B
        ## Exiting from script
        exit 0
        ;;
      VM_QUOTA_ALLOCATED_MEM_PERCENT)
        get_group_vm_quota_allocated_mem_percent
        echo $VM_QUOTA_ALLOCATED_MEM_PERCENT
        ## Exiting from script
        exit 0
        ;;
      VM_QUOTA_TOTAL_CPU)
        get_group_name
        get_group_vm_quota_total_cpu
        echo $VM_QUOTA_TOTAL_CPU
        ## Exiting from script
        exit 0
        ;;
      VM_QUOTA_ALLOCATED_CPU)
        get_group_name
        get_group_vm_quota_allocated_cpu
        echo $VM_QUOTA_ALLOCATED_CPU
        ## Exiting from script
        exit 0
        ;;
      VM_QUOTA_UNALLOCATED_CPU)
        get_group_name
        get_group_vm_quota_unallocated_cpu
        echo $VM_QUOTA_UNALLOCATED_CPU
        ## Exiting from script
        exit 0
        ;;
      VM_QUOTA_ALLOCATED_CPU_PERCENT)
        get_group_name
        get_group_vm_quota_allocated_cpu_percent
        echo $VM_QUOTA_ALLOCATED_CPU_PERCENT
        ## Exiting from script
        exit 0
        ;;
      VM_QUOTA_SYSTEM_DISK_SIZE_B)
        get_group_vm_quota_system_disk_size
        echo $VM_QUOTA_SYSTEM_DISK_SIZE_B
        ## Exiting from script
        exit 0
        ;;
      VM_QUOTA_SYSTEM_DISK_ALLOCATED_B)
        get_group_vm_quota_system_disk_allocated
        echo $VM_QUOTA_SYSTEM_DISK_ALLOCATED_B
        ## Exiting from script
        exit 0
        ;;
      VM_QUOTA_SYSTEM_DISK_UNALLOCATED_B)
        get_group_vm_quota_system_disk_unallocated
        echo $VM_QUOTA_SYSTEM_DISK_UNALLOCATED_B
        ## Exiting from script
        exit 0
        ;;
      --help|-h)
        help_group
        ## Exiting from script
        exit 0
        ;;
      *)
        help_group
        ## Exiting from script
        exit 0
        ;;
    esac
    ;;
  USER)
    user_id=$2
    case $3 in
      VM_QUOTA_ALLOCATED_MEM_B)
        get_user_vm_quota_allocated_mem
        echo $VM_QUOTA_ALLOCATED_MEM_B
        ## Exiting from script
        exit 0
        ;;
      VM_QUOTA_UNALLOCATED_MEM_B)
        get_user_vm_quota_unallocated_mem
        echo $VM_QUOTA_UNALLOCATED_MEM_B
        ## Exiting from script
        exit 0
        ;;
      VM_QUOTA_ALLOCATED_CPU)
        tmpdir=/tmp/bashone
        tmpfile=$tmpdir/USERLIST_for_VM_QUOTA_ALLOCATED_CPU
        check_tmp_file
        get_user_name
        get_user_vm_quota_allocated_cpu
        echo $VM_QUOTA_ALLOCATED_CPU
        ## Exiting from script
        exit 0
        ;;
      VM_QUOTA_UNALLOCATED_CPU)
        GID=$(oneuser show $user_id -x | grep -w "GID" | grep -oE '*[0-9]+')
        group_id=$GID
        get_group_name
        get_user_name
        tmpdir=/tmp/bashone
        tmpfile=$tmpdir/USERLIST_for_VM_QUOTA_ALLOCATED_CPU
        check_tmp_file
        get_user_vm_quota_unallocated_cpu
        echo $VM_QUOTA_UNALLOCATED_CPU
        ## Exiting from script
        exit 0
        ;;
      VM_QUOTA_SYSTEM_DISK_ALLOCATED_B)
        get_user_vm_quota_system_disk_allocated
        echo $VM_QUOTA_SYSTEM_DISK_ALLOCATED_B
        ## Exiting from script
        exit 0
        ;;
      VM_QUOTA_SYSTEM_DISK_UNALLOCATED_B)
        get_user_vm_quota_system_disk_unallocated
        echo $VM_QUOTA_SYSTEM_DISK_UNALLOCATED_B
        ## Exiting from script
        exit 0
        ;;
      --help|-h)
        help_user
        ## Exiting from script
        exit 0
        ;;
      *)
        help_user
        ## Exiting from script
        exit 0
        ;;
    esac
    ;;
  --help|-h)
    help
    ## Exiting from script
    exit 0
    ;;
  *)
    help
    ## Exiting from script
    exit 0
    ;;
esac
