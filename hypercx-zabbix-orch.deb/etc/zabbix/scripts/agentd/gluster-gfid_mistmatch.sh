#!/bin/bash

#----------------------------------------------------------------------------------------------+
# Author: Franco Diaz Hurtado                                                                  |
# Owner: Virtalus                                                                              |
# Script version: 1.0.0                                                                        |
# Brief summary of the script: The script will check for gfid mismatch on the gluster rotated  |
#                              logs and will continue if this orchestrator is the leader.      |
#                              This script is for orchestrators only.                          |
#----------------------------------------------------------------------------------------------+

# Main vars
leader=$(onezone show 0 | grep leader | awk '{print $2}')
host_name=$(cat /etc/hostname)
volname=$1
if [ ! -f /tmp/vollist.tmp ];
  then
    touch /tmp/vollist.tmp
fi
file=/tmp/vollist.tmp
df -hT | grep fuse.glusterfs | grep -v '/dev' | awk -F '/' '{print $2}' | awk '{print $1}' > $file
volcount=$(cat $file | wc -l)
logdir=/var/log/glusterfs
DATE="$(date --date="yesterday" +%Y-%m-%d)"

# Main functions
orch_status(){
  ## Is this orchestrator the leader?
  if [ "${host_name}" != "${leader}" ]
    then
      ## This is not the orchestrator leader
      echo 0
      exit 0
  fi
}

get_logfile(){
  ## Get logfile for each gluster volume
  for (( i=1; $i <= $volcount; i++ ))
    do
      volname=$(sed -n ${i}p $file)
      if [ "$i" -eq 1 ];
        then
          logfile=${logdir}/$(df -hT | grep fuse.glusterfs | grep $volname | grep -v '/dev' | awk '{print $NF}' | tr / - | awk '{print (NR ==   1 ? substr($0,2) : $0)}').log_${DATE}
        else
          logfile=${logdir}/$(df -hT | grep fuse.glusterfs | grep $volname | grep -v '/dev' | awk '{print $NF}' | tr / - | awk '{print (NR == 1 ? substr($0,2) : $0)}')_$i.log_${DATE}
      fi
  done
}

get_gfid_mismatch(){
  ## Get GFID mismatch from rotated logfile
  cat ${logfile} | grep 'gfid differs' | awk '{print $8}' | awk -F ':' '{print $1}' | sort | uniq | wc -l
}

# Body script
orch_status
get_logfile
get_gfid_mismatch

exit 0
