#!/bin/bash

#----------------------------------------------------------------------------------------------+
# Author: Franco Diaz Hurtado                                                                  |
# Owner: Virtalus                                                                              |
# Script version: 1.0.0                                                                        |
# Brief summary of the script: The script check the integrity of the specified fil. The        |
#                              reference files will be those ones from the orchestrator leader.|
#                              This script is for orchestrators only.                          |
#----------------------------------------------------------------------------------------------+

# Main vars
leader=$(onezone show 0 | grep leader | awk '{print $2}')
leader_id=$(echo ${leader} | awk -F "orchestrator" '{print $2}')
host_name=$(cat /etc/hostname)
src_file=$1
filename=$(echo "$1" | awk -F "/" '{print $NF}')

# Main functions
check_integrity(){
  ## Check if files content is the same between remote and local file
  ssh root@${remotehost1} "cat ${src_file}" | diff - ${src_file} 1>/dev/null
  if [ $? -eq 1 ];
    then
      ## The files differ
      echo "1" | grep 1 | wc -l
    else
      ssh root@${remotehost2} "cat ${src_file}" | diff - ${src_file} 1>/dev/null
      if [ $? -eq 1 ];
        then
          ## The files differ
          echo "1" | grep 1 | wc -l
        else
          ## The files content is the same
          echo "0" | grep 1 | wc -l
      fi
  fi
}

# Body script
## Is this orchestrator the leader?
if [ "${host_name}" != "${leader}" ]
  then
    ## This is not the orchestrator leader, then, reset flag
    echo "0" | grep 1 | wc -l
    exit 0
  else
    ## This is the orchestrator leader
    if [ ! -d ${dst_dir} ];
      then
        mkdir -p ${dst_file}
    fi
    dst_file=${dst_dir}/${filename}
    if [ "${leader_id}" -eq 1 ];
      then
        ## orchestrator1 is the leader
        remotehost1=orchestrator2
        remotehost2=orchestrator3
      elif [ "${leader_id}" -eq 2 ];
        then
          ## orchestrator2 is the leader
          remotehost1=orchestrator1
          remotehost2=orchestrator3
      else
        ## orchestrator3 is the leader
        remotehost1=orchestrator1
        remotehost2=orchestrator2
    fi
    check_integrity
fi

exit 0
