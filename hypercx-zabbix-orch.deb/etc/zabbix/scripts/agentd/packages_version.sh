#!/bin/bash

#----------------------------------------------------------------------------------------------+
# Author: Franco Diaz Hurtado                                                                  |
# Owner: Virtalus                                                                              |
# Script version: 1.0.1                                                                        |
# Brief summary of the script: The script will gather current version for specified service:   |
#                              - "0": If is installed and matched with latest stable defined   |
#                              version on template, or if package is not installed.            |
#                              - "1": If is installed and dont matched with latest stable      |
#                              defined version on template.                                    |
#                              This script is for orchestrators only.                          |
#----------------------------------------------------------------------------------------------+

# Main functions
service_exists(){
if [ "$name" == "glusterfs-server" ] || [ "$name" == "glusterfs-client" ];
  then
    sleep 0
  elif [[ $(systemctl list-units --all -t service --full --no-legend "$name.service" | sed 's/^\s*//g' | cut -f1 -d' ') != $name.service ]];
    then
      ## Service is not installed
      echo 0
      ## Exiting from script
      exit 0
fi
}

get_version(){
  x=$(dpkg -l | grep -w $name | grep ii | awk '{print $3}' | head -n 1)
}

compare_version(){
  if [ "$version" != "$latest_version" ];
    then
      echo 1
    else
      echo 0
  fi
}

# Body script
name=$1
latest_version=$2
service_exists
## If exist script will continue
case $1 in
## x.y.z versioning type
hypercx-vault|hypercx-dr|opennebula)
  get_version
  version=$(echo ${x:0:5})
  compare_version
  ;;

## x.y versioning type
glusterfs-server|glusterfs-client)
  dpkg -l | grep $1 | grep ii &> /dev/null
  if [ $? -eq 0 ];
    then
      ## Package is installed
      get_version
      version=$(echo ${x:0:4})
      compare_version
    else
      ## Package is not installed
      echo 0
  fi
  ;;

## Zabbix versioning type
zabbix-agent|zabbix-agent2)
  get_version
  version=$(echo ${x:2:5})
  compare_version
  ;;
esac

exit 0
