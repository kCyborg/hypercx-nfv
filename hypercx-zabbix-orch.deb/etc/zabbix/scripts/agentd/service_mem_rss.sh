#!/bin/bash

#----------------------------------------------------------------------------------------------+
# Author: Franco Diaz Hurtado                                                                  |
# Owner: Virtalus                                                                              |
# Script version: 1.0.0                                                                        |
# Brief summary of the script: The script gather information about memory consume of some      |
#                              specific services and deliver its value in %.                   |
#                              This script is for orchestrators only.                          |
#----------------------------------------------------------------------------------------------+

# Main vars
if [ ! -d /tmp/host_resources ];
  then
    mkdir -p /tmp/host_resources
fi
tmp_dir="/tmp/host_resources"

# Main functions
get_service_used_mem_percent(){
SERVICE_USED_MEM_PERCENT=`ps -eo cmd,%mem --sort=-%mem | egrep "$service" | grep -v "grep" | awk '{print $NF}' | paste -sd+ - | bc | awk '{printf "%f", $0}'`
}

check_if_null(){
  if [ -z $SERVICE_USED_MEM_PERCENT ];
    then
      SERVICE_USED_MEM_PERCENT=0.0000
  fi
}

print_result(){
  echo ${SERVICE_USED_MEM_PERCENT::-5}
}

# Body script
case $1 in

  mysqld)
    service=$1
    get_service_used_mem_percent
    check_if_null
    print_result
    cat /dev/null > ${tmp_dir}/SERVICE_USED_MEM_PERCENT_$1
    ;;

  oned)
    service=$1
    get_service_used_mem_percent
    check_if_null
    print_result
    cat /dev/null > ${tmp_dir}/SERVICE_USED_MEM_PERCENT_$1
    ;;

  gluster)
    service=$1
    get_service_used_mem_percent
    check_if_null
    print_result
    cat /dev/null > ${tmp_dir}/SERVICE_USED_MEM_PERCENT_$1
    ;;

  ruby)
    service=$1
    get_service_used_mem_percent
    check_if_null
    print_result
    cat /dev/null > ${tmp_dir}/SERVICE_USED_MEM_PERCENT_$1
    ;;

  therest)
    if [ -f ${tmp_dir}/SERVICE_USED_MEM_therest ];
      then
        cat /dev/null > ${tmp_dir}/SERVICE_USED_MEM_therest
      else
        touch ${tmp_dir}/SERVICE_USED_MEM_therest
    fi
    service=mysqld
    get_service_used_mem_percent
    check_if_null
    echo ${SERVICE_USED_MEM_PERCENT::-5} >> ${tmp_dir}/SERVICE_USED_MEM_PERCENT_$1
    service=oned
    get_service_used_mem_percent
    check_if_null
    echo ${SERVICE_USED_MEM_PERCENT::-5} >> ${tmp_dir}/SERVICE_USED_MEM_PERCENT_$1
    service=gluster
    get_service_used_mem_percent
    check_if_null
    echo ${SERVICE_USED_MEM_PERCENT::-5} >> ${tmp_dir}/SERVICE_USED_MEM_PERCENT_$1
    service=ruby
    get_service_used_mem_percent
    check_if_null
    echo ${SERVICE_USED_MEM_PERCENT::-5} >> ${tmp_dir}/SERVICE_USED_MEM_PERCENT_$1

    ## The rest used MEM [%]
    T=$(free -b | grep Mem | awk '{print $2}')
    P=$(free -b | grep Mem | awk '{print $NF}')
    D=$(printf "%.3f\n" $((10**3 * $P/$T))e-3)
    float=$(expr $D*100 | bc)
    AVAILABLE_MEM_PERCENT=$(echo $float)
    SERVICES_USED_MEM_PERCENT=$(cat ${tmp_dir}/SERVICE_USED_MEM_PERCENT_$1 | paste -sd+ - | bc)
    THE_REST=$(awk "BEGIN{ print 100 - ${AVAILABLE_MEM_PERCENT} - ${SERVICES_USED_MEM_PERCENT} }")
    echo $THE_REST
    cat /dev/null > ${tmp_dir}/SERVICE_USED_MEM_PERCENT_$1
    ;;

  available)
    ## The available MEM without swap [%]
    T=$(free -b | grep Mem | awk '{print $2}')
    P=$(free -b | grep Mem | awk '{print $NF}')
    D=$(printf "%.3f\n" $((10**3 * $P/$T))e-3)
    float=$(expr $D*100 | bc)
    AVAILABLE_MEM_PERCENT=$(echo ${float::-2})
    echo $AVAILABLE_MEM_PERCENT
    ;;

  *)
    ## Exiting from script
    exit 0
    ;;
esac
